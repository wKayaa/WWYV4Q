import re

class SecretParser:
    def __init__(self, debug=False):
        self.debug = debug

    def parse(self, content, filename="", host=""):
        creds = []
        # Patterns pour AWS, SMTP, API, etc. (exemple simple, à enrichir)
        aws = re.findall(r"AKIA[0-9A-Z]{16}", content)
        smtp = re.findall(r"SMTP.*?=.*", content)
        # ...
        if aws: creds += [{"type": "aws", "key": k, "host": host, "file": filename} for k in aws]
        if smtp: creds += [{"type": "smtp", "raw": s, "host": host, "file": filename} for s in smtp]
        if self.debug: print(f"[PARSE] {filename}@{host} : {creds}")
        return creds