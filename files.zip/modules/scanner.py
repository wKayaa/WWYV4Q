import threading, queue, socket, requests, ipaddress
from ipwhois import IPWhois

COMMON_PORTS = [6443, 10250, 10255, 2375, 2379, 2380, 8080, 80, 443, 6379, 9000, 5000, 8081]

class Scanner:
    def __init__(self, targets, threads=500, timeout=2, debug=False):
        self.targets = targets
        self.threads = threads
        self.timeout = timeout
        self.q = queue.Queue()
        self.results = {}
        self.debug = debug

    def enrich_ip(self, ip):
        try:
            data = IPWhois(ip).lookup_rdap(depth=1)
            return {
                "asn": data.get("asn"),
                "org": data.get("network", {}).get("name"),
                "country": data.get("asn_country_code"),
            }
        except Exception:
            return {}
    
    def scan_worker(self):
        while True:
            tgt = self.q.get()
            if tgt is None: break
            ip = tgt
            hostinfo = self.enrich_ip(ip)
            hostinfo["ports"] = {}
            for port in COMMON_PORTS:
                try:
                    s = socket.create_connection((ip, port), timeout=self.timeout)
                    s.close()
                    # Détection de service par bannière HTTP
                    try:
                        r = requests.get(f"http://{ip}:{port}", timeout=2)
                        banner = r.headers.get("Server", "") + r.text[:100]
                    except Exception:
                        banner = ""
                    hostinfo["ports"][port] = {"open": True, "banner": banner}
                except Exception:
                    hostinfo["ports"][port] = {"open": False}
            self.results[ip] = hostinfo
            if self.debug: print(f"[SCAN] {ip} -> {hostinfo}")
            self.q.task_done()

    def run_scan(self):
        for ip in self.targets:
            self.q.put(ip)
        threads = []
        for _ in range(min(self.threads, len(self.targets))):
            t = threading.Thread(target=self.scan_worker)
            t.start()
            threads.append(t)
        self.q.join()
        for _ in threads: self.q.put(None)
        for t in threads: t.join()
        return self.results