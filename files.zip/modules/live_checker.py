import smtplib, boto3

class LiveChecker:
    def __init__(self, debug=False):
        self.debug = debug

    def check_all(self, creds):
        results = []
        for c in creds:
            valid = False
            if c["type"] == "aws":
                try:
                    client = boto3.client('sts', aws_access_key_id=c["key"], aws_secret_access_key=c.get("secret", ""))
                    resp = client.get_caller_identity()
                    valid = True
                    c["identity"] = resp
                except Exception as e:
                    c["error"] = str(e)
            if c["type"] == "smtp":
                # SMTP Live check (STARTTLS, etc.)
                # ... compléter
                pass
            c["valid"] = valid
            results.append(c)
            if self.debug: print(f"[CHECK] {c}")
        return results