import requests

class BotSender:
    def __init__(self, telegram_token=None, discord_webhook=None):
        self.telegram_token = telegram_token
        self.discord_webhook = discord_webhook

    def send_summary(self, data, export_path):
        msg = f"Résultats CloudCracker:\nScan: {len(data.get('scan',{}))} hosts\nExploits: {len(data.get('exploit',{}))}\nCreds: {len(data.get('creds',[]))}"
        if self.telegram_token:
            # TODO: upload file + send msg via python-telegram-bot
            print("[BOT] Envoi Telegram (à implémenter)")
        if self.discord_webhook:
            # TODO: upload file + send summary
            print("[BOT] Envoi Discord (à implémenter)")