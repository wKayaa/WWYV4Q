"""
Service Detection Module
Advanced service fingerprinting and application detection
"""

import asyncio
import aiohttp
import re
import ssl
from typing import Dict, List, Optional, Any
import logging


class ServiceDetector:
    """Advanced service detection and fingerprinting"""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Service signatures for detection
        self.service_signatures = self._load_service_signatures()
    
    def _load_service_signatures(self) -> Dict[str, Any]:
        """Load service detection signatures"""
        return {
            'kubernetes': {
                'ports': [6443, 8080, 8443, 10250, 10255],
                'endpoints': ['/api', '/version', '/healthz'],
                'headers': ['kubernetes', 'k8s'],
                'content_patterns': ['kubernetes', 'apiVersion']
            },
            'docker': {
                'ports': [2375, 2376, 2377],
                'endpoints': ['/version', '/info'],
                'headers': ['docker'],
                'content_patterns': ['docker', 'container']
            },
            'jenkins': {
                'ports': [8080, 8443],
                'endpoints': ['/login', '/api/json'],
                'headers': ['jenkins', 'hudson'],
                'content_patterns': ['jenkins', 'hudson', 'build']
            },
            'grafana': {
                'ports': [3000],
                'endpoints': ['/api/health', '/login'],
                'headers': ['grafana'],
                'content_patterns': ['grafana', 'dashboard']
            },
            'prometheus': {
                'ports': [9090],
                'endpoints': ['/metrics', '/api/v1'],
                'headers': ['prometheus'],
                'content_patterns': ['prometheus', 'metric']
            },
            'elasticsearch': {
                'ports': [9200, 9300],
                'endpoints': ['/', '/_cluster/health'],
                'headers': ['elasticsearch'],
                'content_patterns': ['elasticsearch', 'lucene']
            },
            'redis': {
                'ports': [6379],
                'endpoints': [],
                'protocol': 'tcp',
                'commands': ['INFO', 'PING']
            },
            'etcd': {
                'ports': [2379, 2380],
                'endpoints': ['/version', '/health'],
                'headers': ['etcd'],
                'content_patterns': ['etcd']
            }
        }
    
    async def detect_service(self, host: str, port: int, 
                           banner: Optional[str] = None) -> Dict[str, Any]:
        """
        Comprehensive service detection for a specific host:port
        """
        detection_results = {
            'host': host,
            'port': port,
            'detected_services': [],
            'confidence_scores': {},
            'additional_info': {}
        }
        
        # Banner-based detection
        if banner:
            banner_results = self._detect_from_banner(banner, port)
            if banner_results:
                detection_results['detected_services'].extend(banner_results)
        
        # Port-based detection
        port_results = self._detect_from_port(port)
        if port_results:
            detection_results['detected_services'].extend(port_results)
        
        # HTTP-based detection
        if port in [80, 443, 8080, 8443, 3000, 9090, 9200]:
            http_results = await self._detect_http_service(host, port)
            if http_results:
                detection_results.update(http_results)
        
        # Kubernetes-specific detection
        if port in [6443, 8080, 10250, 10255]:
            k8s_results = await self._detect_kubernetes_detailed(host, port)
            if k8s_results:
                detection_results['additional_info']['kubernetes'] = k8s_results
        
        # TCP protocol detection
        tcp_results = await self._detect_tcp_service(host, port)
        if tcp_results:
            detection_results['additional_info']['tcp_info'] = tcp_results
        
        # Calculate confidence scores
        self._calculate_confidence_scores(detection_results)
        
        return detection_results
    
    def _detect_from_banner(self, banner: str, port: int) -> List[str]:
        """Detect services based on banner information"""
        detected = []
        banner_lower = banner.lower()
        
        # SSH detection
        if 'ssh' in banner_lower:
            detected.append('ssh')
            if 'openssh' in banner_lower:
                detected.append('openssh')
        
        # HTTP server detection
        if any(indicator in banner_lower for indicator in ['http', 'server:']):
            detected.append('http')
            
            if 'nginx' in banner_lower:
                detected.append('nginx')
            elif 'apache' in banner_lower:
                detected.append('apache')
            elif 'iis' in banner_lower:
                detected.append('iis')
        
        # FTP detection
        if 'ftp' in banner_lower:
            detected.append('ftp')
        
        # Database detection
        if 'mysql' in banner_lower:
            detected.append('mysql')
        elif 'postgresql' in banner_lower:
            detected.append('postgresql')
        
        return detected
    
    def _detect_from_port(self, port: int) -> List[str]:
        """Detect likely services based on port number"""
        port_mappings = {
            22: ['ssh'],
            21: ['ftp'],
            23: ['telnet'],
            25: ['smtp'],
            53: ['dns'],
            80: ['http'],
            110: ['pop3'],
            143: ['imap'],
            443: ['https', 'http'],
            993: ['imaps'],
            995: ['pop3s'],
            3306: ['mysql'],
            5432: ['postgresql'],
            6379: ['redis'],
            3000: ['grafana'],
            9090: ['prometheus'],
            9200: ['elasticsearch'],
            6443: ['kubernetes-api'],
            8080: ['http', 'jenkins', 'kubernetes'],
            10250: ['kubelet'],
            2375: ['docker-api'],
            2376: ['docker-api-tls']
        }
        
        return port_mappings.get(port, [])
    
    async def _detect_http_service(self, host: str, port: int) -> Dict[str, Any]:
        """Detailed HTTP service detection"""
        http_info = {}
        
        try:
            # Determine protocol
            protocol = 'https' if port in [443, 8443] else 'http'
            base_url = f"{protocol}://{host}:{port}"
            
            # Create SSL context for HTTPS
            ssl_context = None
            if protocol == 'https':
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE
            
            async with aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(ssl=ssl_context),
                timeout=aiohttp.ClientTimeout(total=10)
            ) as session:
                
                # Test multiple endpoints
                endpoints_to_test = ['/', '/api', '/login', '/admin', '/health']
                
                for endpoint in endpoints_to_test:
                    try:
                        url = f"{base_url}{endpoint}"
                        async with session.get(url) as response:
                            
                            if response.status < 500:  # Any response except server error
                                if 'http_responses' not in http_info:
                                    http_info['http_responses'] = {}
                                
                                http_info['http_responses'][endpoint] = {
                                    'status': response.status,
                                    'headers': dict(response.headers),
                                    'content_type': response.headers.get('content-type', '')
                                }
                                
                                # Read content for application detection
                                try:
                                    content = await response.text()
                                    app_detection = self._detect_web_application(content, response.headers)
                                    if app_detection:
                                        http_info['detected_applications'] = http_info.get('detected_applications', [])
                                        http_info['detected_applications'].extend(app_detection)
                                except:
                                    pass
                                
                                break  # Found a responsive endpoint
                    
                    except asyncio.TimeoutError:
                        continue
                    except Exception:
                        continue
        
        except Exception as e:
            self.logger.debug(f"HTTP detection failed for {host}:{port}: {e}")
        
        return http_info
    
    async def _detect_kubernetes_detailed(self, host: str, port: int) -> Dict[str, Any]:
        """Detailed Kubernetes service detection"""
        k8s_info = {}
        
        try:
            # Determine likely protocol based on port
            protocol = 'https' if port == 6443 else 'http'
            base_url = f"{protocol}://{host}:{port}"
            
            # SSL context for secure connections
            ssl_context = None
            if protocol == 'https':
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE
            
            async with aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(ssl=ssl_context),
                timeout=aiohttp.ClientTimeout(total=10)
            ) as session:
                
                # Test Kubernetes endpoints
                k8s_endpoints = {
                    '/version': 'version_info',
                    '/api/v1': 'api_access',
                    '/healthz': 'health_check',
                    '/metrics': 'metrics_endpoint',
                    '/pods': 'kubelet_pods'
                }
                
                for endpoint, info_type in k8s_endpoints.items():
                    try:
                        url = f"{base_url}{endpoint}"
                        async with session.get(url) as response:
                            
                            k8s_info[info_type] = {
                                'status': response.status,
                                'accessible': response.status in [200, 401, 403]
                            }
                            
                            if response.status == 200:
                                try:
                                    if response.headers.get('content-type', '').startswith('application/json'):
                                        data = await response.json()
                                        k8s_info[info_type]['data'] = data
                                        
                                        # Extract version information
                                        if 'gitVersion' in data:
                                            k8s_info['kubernetes_version'] = data['gitVersion']
                                        if 'platform' in data:
                                            k8s_info['platform'] = data['platform']
                                except:
                                    content = await response.text()
                                    k8s_info[info_type]['content_preview'] = content[:200]
                    
                    except Exception:
                        continue
                
                # Classify Kubernetes component
                k8s_info['component_type'] = self._classify_kubernetes_component(port, k8s_info)
        
        except Exception as e:
            self.logger.debug(f"Kubernetes detection failed for {host}:{port}: {e}")
        
        return k8s_info
    
    def _classify_kubernetes_component(self, port: int, detection_data: Dict[str, Any]) -> str:
        """Classify the type of Kubernetes component"""
        
        if port == 6443:
            return 'kube-apiserver'
        elif port == 8080:
            if detection_data.get('api_access', {}).get('accessible'):
                return 'kube-apiserver-insecure'
            else:
                return 'unknown-http-service'
        elif port == 10250:
            return 'kubelet'
        elif port == 10255:
            return 'kubelet-readonly'
        
        return 'unknown-kubernetes-component'
    
    async def _detect_tcp_service(self, host: str, port: int) -> Dict[str, Any]:
        """Generic TCP service detection"""
        tcp_info = {}
        
        try:
            # Test TCP connection
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(host, port),
                timeout=5
            )
            
            tcp_info['tcp_connection'] = 'successful'
            
            # Try to read initial data (some services send greetings)
            try:
                initial_data = await asyncio.wait_for(reader.read(1024), timeout=3)
                if initial_data:
                    tcp_info['initial_response'] = initial_data.decode('utf-8', errors='ignore')
            except asyncio.TimeoutError:
                tcp_info['initial_response'] = 'no_immediate_response'
            
            # Test Redis protocol if port suggests it
            if port == 6379:
                redis_info = await self._test_redis_protocol(reader, writer)
                tcp_info['redis_test'] = redis_info
            
            writer.close()
            await writer.wait_closed()
        
        except Exception as e:
            tcp_info['tcp_connection'] = f'failed: {str(e)}'
        
        return tcp_info
    
    async def _test_redis_protocol(self, reader, writer) -> Dict[str, Any]:
        """Test Redis protocol commands"""
        redis_info = {}
        
        try:
            # Send Redis PING command
            writer.write(b"PING\r\n")
            await writer.drain()
            
            response = await asyncio.wait_for(reader.read(1024), timeout=3)
            redis_info['ping_response'] = response.decode('utf-8', errors='ignore')
            
            if '+PONG' in redis_info['ping_response']:
                redis_info['protocol_confirmed'] = True
                
                # Try INFO command for more details
                writer.write(b"INFO\r\n")
                await writer.drain()
                
                info_response = await asyncio.wait_for(reader.read(4096), timeout=3)
                redis_info['info_response'] = info_response.decode('utf-8', errors='ignore')
            
        except Exception as e:
            redis_info['test_error'] = str(e)
        
        return redis_info
    
    def _detect_web_application(self, content: str, headers: Dict[str, str]) -> List[str]:
        """Detect web applications from HTTP content and headers"""
        detected_apps = []
        content_lower = content.lower()
        
        # Application signatures
        app_signatures = {
            'jenkins': [
                'jenkins',
                'hudson',
                'build queue',
                'jenkins-session'
            ],
            'kubernetes-dashboard': [
                'kubernetes dashboard',
                'k8s-app',
                'kubernetes.io'
            ],
            'grafana': [
                'grafana',
                'login.username',
                'grafana-app'
            ],
            'prometheus': [
                'prometheus',
                'query_range',
                'prometheus.io'
            ],
            'elasticsearch': [
                'elasticsearch',
                'elastic',
                'lucene_version'
            ],
            'kibana': [
                'kibana',
                'kbn-version',
                'elastic'
            ],
            'minio': [
                'minio',
                'object storage',
                'minio browser'
            ],
            'gitlab': [
                'gitlab',
                'gitlab-workhorse',
                'gitlab.com'
            ],
            'docker-registry': [
                'docker-distribution',
                'registry',
                'docker-content-digest'
            ],
            'portainer': [
                'portainer',
                'docker management',
                'portainer.io'
            ]
        }
        
        # Check content for signatures
        for app_name, signatures in app_signatures.items():
            if any(sig in content_lower for sig in signatures):
                detected_apps.append(app_name)
        
        # Check headers for application indicators
        header_indicators = {
            'server': ['nginx', 'apache', 'iis'],
            'x-powered-by': ['express', 'php', 'asp.net'],
            'x-jenkins': ['jenkins'],
            'x-grafana-org-id': ['grafana'],
            'x-elastic-product': ['elasticsearch']
        }
        
        for header_name, header_value in headers.items():
            header_lower = header_name.lower()
            value_lower = str(header_value).lower()
            
            if header_lower in header_indicators:
                for indicator in header_indicators[header_lower]:
                    if indicator in value_lower:
                        detected_apps.append(indicator)
        
        return list(set(detected_apps))  # Remove duplicates
    
    def _calculate_confidence_scores(self, detection_results: Dict[str, Any]):
        """Calculate confidence scores for detected services"""
        
        detected_services = detection_results['detected_services']
        confidence_scores = {}
        
        for service in detected_services:
            score = 0.0
            
            # Base score for detection
            score += 0.3
            
            # Bonus for port match
            expected_ports = self.service_signatures.get(service, {}).get('ports', [])
            if detection_results['port'] in expected_ports:
                score += 0.3
            
            # Bonus for banner match
            if 'tcp_info' in detection_results.get('additional_info', {}):
                if service in str(detection_results['additional_info']['tcp_info']).lower():
                    score += 0.2
            
            # Bonus for HTTP response match
            if 'http_responses' in detection_results:
                for endpoint_data in detection_results['http_responses'].values():
                    if service in str(endpoint_data).lower():
                        score += 0.2
                        break
            
            confidence_scores[service] = min(1.0, score)
        
        detection_results['confidence_scores'] = confidence_scores