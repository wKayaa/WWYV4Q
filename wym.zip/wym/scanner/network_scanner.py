"""
Network Scanner Module
High-performance network scanning and service discovery
"""

import asyncio
import socket
import aiohttp
import nmap
from typing import Dict, List, Tuple, Any, Optional
import logging
from concurrent.futures import ThreadPoolExecutor
import time


class NetworkScanner:
    """Advanced network scanner with async capabilities"""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.nm = nmap.PortScanner()
        self.executor = ThreadPoolExecutor(max_workers=config.scanner.max_concurrent)
        
        # Scanning statistics
        self.stats = {
            'hosts_scanned': 0,
            'ports_scanned': 0,
            'services_found': 0,
            'scan_start_time': None,
            'scan_end_time': None
        }
    
    async def scan_range(self, ip_range: str, ports: List[int], 
                        concurrency: Optional[int] = None) -> Dict[str, Any]:
        """
        Scan IP range for open ports and services
        
        Args:
            ip_range: CIDR notation IP range (e.g., "192.168.1.0/24")
            ports: List of ports to scan
            concurrency: Override default concurrency limit
            
        Returns:
            Dictionary containing scan results
        """
        
        self.logger.info(f"Starting network scan for {ip_range} on ports {ports}")
        self.stats['scan_start_time'] = time.time()
        
        # Parse IP range
        hosts = self._parse_ip_range(ip_range)
        port_list = ','.join(map(str, ports))
        
        # Use provided concurrency or config default
        max_concurrent = concurrency or self.config.scanner.max_concurrent
        semaphore = asyncio.Semaphore(max_concurrent)
        
        # Create scan tasks
        scan_tasks = []
        for host in hosts:
            task = self._scan_host_with_semaphore(semaphore, host, port_list)
            scan_tasks.append(task)
        
        # Execute scans with controlled concurrency
        self.logger.info(f"Scanning {len(hosts)} hosts with {max_concurrent} concurrent threads")
        scan_results = await asyncio.gather(*scan_tasks, return_exceptions=True)
        
        # Process results
        results = self._process_scan_results(scan_results, ip_range)
        
        self.stats['scan_end_time'] = time.time()
        scan_duration = self.stats['scan_end_time'] - self.stats['scan_start_time']
        
        self.logger.info(f"Network scan completed in {scan_duration:.2f} seconds")
        self.logger.info(f"Found {results['summary']['total_open_ports']} open ports on {results['summary']['responsive_hosts']} hosts")
        
        return results
    
    async def _scan_host_with_semaphore(self, semaphore: asyncio.Semaphore, 
                                       host: str, ports: str) -> Dict[str, Any]:
        """Scan single host with semaphore control"""
        async with semaphore:
            return await self._scan_single_host(host, ports)
    
    async def _scan_single_host(self, host: str, ports: str) -> Dict[str, Any]:
        """
        Scan a single host for open ports and services
        """
        host_result = {
            'host': host,
            'status': 'down',
            'ports': {},
            'os': {},
            'scan_time': time.time()
        }
        
        try:
            # Run nmap scan in thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            scan_result = await loop.run_in_executor(
                self.executor,
                self._nmap_scan,
                host,
                ports
            )
            
            if host in scan_result.all_hosts():
                host_result['status'] = scan_result[host].state()
                
                # Process open ports
                for port in scan_result[host].all_tcp():
                    port_state = scan_result[host].tcp(port)
                    
                    if port_state['state'] == 'open':
                        port_info = {
                            'port': port,
                            'state': port_state['state'],
                            'service': {
                                'name': port_state.get('name', 'unknown'),
                                'product': port_state.get('product', ''),
                                'version': port_state.get('version', ''),
                                'extrainfo': port_state.get('extrainfo', ''),
                                'conf': port_state.get('conf', '0')
                            }
                        }
                        
                        # Enhanced service detection
                        service_details = await self._enhanced_service_detection(host, port)
                        if service_details:
                            port_info['service'].update(service_details)
                        
                        host_result['ports'][port] = port_info
                        self.stats['services_found'] += 1
                
                # OS detection if available
                if 'osmatch' in scan_result[host]:
                    host_result['os'] = scan_result[host]['osmatch']
                
                self.stats['hosts_scanned'] += 1
                self.stats['ports_scanned'] += len(scan_result[host].all_tcp())
        
        except Exception as e:
            self.logger.debug(f"Scan failed for {host}: {e}")
            host_result['error'] = str(e)
        
        return host_result
    
    def _nmap_scan(self, host: str, ports: str) -> Any:
        """Execute nmap scan (runs in thread pool)"""
        try:
            # Nmap command with service detection
            arguments = f"-sS -sV -O --host-timeout {self.config.scanner.timeout}s"
            
            # Add script scanning if enabled (disabled by default for safety)
            if self.config.scanner.service_detection.get('script_scanning', False):
                arguments += " -sC"
            
            return self.nm.scan(hosts=host, ports=ports, arguments=arguments)
        
        except Exception as e:
            self.logger.debug(f"Nmap scan failed for {host}: {e}")
            return {'scan': {}}
    
    async def _enhanced_service_detection(self, host: str, port: int) -> Dict[str, Any]:
        """
        Enhanced service detection using banner grabbing and HTTP analysis
        """
        service_info = {}
        
        try:
            # Banner grabbing for common services
            if port in [21, 22, 23, 25, 53, 80, 110, 143, 443, 993, 995]:
                banner = await self._grab_banner(host, port)
                if banner:
                    service_info['banner'] = banner
                    
                    # Analyze banner for additional info
                    banner_analysis = self._analyze_banner(banner, port)
                    service_info.update(banner_analysis)
            
            # HTTP-specific detection
            if port in [80, 443, 8080, 8443, 9090]:
                http_info = await self._analyze_http_service(host, port)
                if http_info:
                    service_info.update(http_info)
            
            # Kubernetes-specific detection
            if port in [6443, 8080, 10250, 10255]:
                k8s_info = await self._detect_kubernetes_service(host, port)
                if k8s_info:
                    service_info.update(k8s_info)
        
        except Exception as e:
            self.logger.debug(f"Enhanced service detection failed for {host}:{port}: {e}")
        
        return service_info
    
    async def _grab_banner(self, host: str, port: int, timeout: int = 5) -> Optional[str]:
        """Grab service banner"""
        try:
            reader, writer = await asyncio.wait_for(
                asyncio.open_connection(host, port),
                timeout=timeout
            )
            
            # Send minimal request to trigger banner
            if port == 80:
                writer.write(b"HEAD / HTTP/1.0\r\n\r\n")
            elif port in [21, 22, 25]:
                # These services typically send banner immediately
                pass
            else:
                writer.write(b"\r\n")
            
            await writer.drain()
            
            # Read response
            banner = await asyncio.wait_for(reader.read(1024), timeout=3)
            
            writer.close()
            await writer.wait_closed()
            
            return banner.decode('utf-8', errors='ignore').strip()
        
        except Exception:
            return None
    
    async def _analyze_http_service(self, host: str, port: int) -> Dict[str, Any]:
        """Analyze HTTP/HTTPS services"""
        http_info = {}
        
        try:
            # Determine protocol
            protocol = 'https' if port in [443, 8443] else 'http'
            url = f"{protocol}://{host}:{port}/"
            
            # Create SSL context for HTTPS
            ssl_context = None
            if protocol == 'https':
                import ssl
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE
            
            async with aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(ssl=ssl_context),
                timeout=aiohttp.ClientTimeout(total=10)
            ) as session:
                
                async with session.get(url) as response:
                    http_info['http_status'] = response.status
                    http_info['http_headers'] = dict(response.headers)
                    
                    # Check for common applications
                    server_header = response.headers.get('Server', '').lower()
                    if 'nginx' in server_header:
                        http_info['web_server'] = 'nginx'
                    elif 'apache' in server_header:
                        http_info['web_server'] = 'apache'
                    elif 'iis' in server_header:
                        http_info['web_server'] = 'iis'
                    
                    # Read response body for application detection
                    content = await response.text()
                    app_detection = self._detect_web_application(content, response.headers)
                    if app_detection:
                        http_info['application'] = app_detection
        
        except Exception as e:
            self.logger.debug(f"HTTP analysis failed for {host}:{port}: {e}")
        
        return http_info
    
    async def _detect_kubernetes_service(self, host: str, port: int) -> Dict[str, Any]:
        """Detect Kubernetes-specific services"""
        k8s_info = {}
        
        try:
            # Common Kubernetes endpoints to check
            endpoints = {
                6443: ['/version', '/api/v1'],
                8080: ['/api', '/version'],
                10250: ['/pods', '/stats'],
                10255: ['/pods', '/stats']
            }
            
            if port in endpoints:
                protocol = 'https' if port == 6443 else 'http'
                
                for endpoint in endpoints[port]:
                    try:
                        url = f"{protocol}://{host}:{port}{endpoint}"
                        
                        # SSL context for HTTPS
                        ssl_context = None
                        if protocol == 'https':
                            import ssl
                            ssl_context = ssl.create_default_context()
                            ssl_context.check_hostname = False
                            ssl_context.verify_mode = ssl.CERT_NONE
                        
                        async with aiohttp.ClientSession(
                            connector=aiohttp.TCPConnector(ssl=ssl_context),
                            timeout=aiohttp.ClientTimeout(total=5)
                        ) as session:
                            
                            async with session.get(url) as response:
                                if response.status in [200, 401, 403]:
                                    k8s_info['kubernetes_endpoint'] = True
                                    k8s_info['endpoint_type'] = self._classify_k8s_endpoint(port)
                                    
                                    if response.status == 200:
                                        try:
                                            data = await response.json()
                                            if 'gitVersion' in data:
                                                k8s_info['kubernetes_version'] = data['gitVersion']
                                            if 'platform' in data:
                                                k8s_info['platform'] = data['platform']
                                        except:
                                            pass
                                    
                                    break
                    
                    except Exception:
                        continue
        
        except Exception as e:
            self.logger.debug(f"Kubernetes detection failed for {host}:{port}: {e}")
        
        return k8s_info
    
    def _classify_k8s_endpoint(self, port: int) -> str:
        """Classify Kubernetes endpoint type by port"""
        classifications = {
            6443: 'api_server',
            8080: 'api_server_insecure',
            10250: 'kubelet',
            10255: 'kubelet_read_only'
        }
        return classifications.get(port, 'unknown')
    
    def _detect_web_application(self, content: str, headers: Dict[str, str]) -> Optional[str]:
        """Detect web application from content and headers"""
        
        content_lower = content.lower()
        
        # Common application signatures
        signatures = {
            'jenkins': ['jenkins', 'hudson'],
            'kubernetes_dashboard': ['kubernetes dashboard', 'k8s dashboard'],
            'grafana': ['grafana'],
            'prometheus': ['prometheus'],
            'kibana': ['kibana'],
            'elasticsearch': ['elasticsearch'],
            'minio': ['minio'],
            'redis': ['redis'],
            'docker_registry': ['docker-distribution'],
            'gitlab': ['gitlab'],
            'jira': ['atlassian jira'],
            'confluence': ['atlassian confluence']
        }
        
        for app_name, indicators in signatures.items():
            if any(indicator in content_lower for indicator in indicators):
                return app_name
        
        # Check headers
        for header_name, header_value in headers.items():
            if header_name.lower() == 'x-powered-by':
                return f"powered_by_{header_value}"
        
        return None
    
    def _analyze_banner(self, banner: str, port: int) -> Dict[str, Any]:
        """Analyze service banner for additional information"""
        banner_info = {}
        banner_lower = banner.lower()
        
        # SSH detection
        if port == 22 and 'ssh' in banner_lower:
            if 'openssh' in banner_lower:
                banner_info['ssh_implementation'] = 'openssh'
            elif 'dropbear' in banner_lower:
                banner_info['ssh_implementation'] = 'dropbear'
        
        # HTTP server detection
        elif port in [80, 443] and 'server:' in banner_lower:
            server_line = [line for line in banner.split('\n') if 'server:' in line.lower()]
            if server_line:
                banner_info['http_server'] = server_line[0].split(':', 1)[1].strip()
        
        # FTP detection
        elif port == 21:
            if 'vsftpd' in banner_lower:
                banner_info['ftp_server'] = 'vsftpd'
            elif 'proftpd' in banner_lower:
                banner_info['ftp_server'] = 'proftpd'
        
        return banner_info
    
    def _parse_ip_range(self, ip_range: str) -> List[str]:
        """Parse CIDR notation to list of IP addresses"""
        import ipaddress
        
        try:
            network = ipaddress.IPv4Network(ip_range, strict=False)
            return [str(ip) for ip in network.hosts()]
        except Exception as e:
            self.logger.error(f"Failed to parse IP range {ip_range}: {e}")
            return []
    
    def _process_scan_results(self, scan_results: List[Any], ip_range: str) -> Dict[str, Any]:
        """Process and summarize scan results"""
        
        processed_results = {
            'scan_info': {
                'ip_range': ip_range,
                'scan_time': self.stats['scan_start_time'],
                'duration': self.stats['scan_end_time'] - self.stats['scan_start_time'],
                'scanner_version': 'EKS Security Framework v1.0'
            },
            'hosts': {},
            'summary': {
                'total_hosts': len(scan_results),
                'responsive_hosts': 0,
                'total_open_ports': 0,
                'unique_services': set(),
                'potential_kubernetes': 0
            },
            'statistics': dict(self.stats)
        }
        
        # Process individual host results
        for result in scan_results:
            if isinstance(result, Exception):
                continue
            
            if result['status'] == 'up':
                processed_results['summary']['responsive_hosts'] += 1
                
                host_ip = result['host']
                processed_results['hosts'][host_ip] = result
                
                # Count open ports and services
                for port_data in result['ports'].values():
                    processed_results['summary']['total_open_ports'] += 1
                    service_name = port_data['service']['name']
                    processed_results['summary']['unique_services'].add(service_name)
                    
                    # Check for Kubernetes indicators
                    if (port_data.get('kubernetes_endpoint') or 
                        service_name in ['kubernetes', 'k8s'] or
                        port_data['port'] in [6443, 8080, 10250, 10255]):
                        processed_results['summary']['potential_kubernetes'] += 1
        
        # Convert set to list for JSON serialization
        processed_results['summary']['unique_services'] = list(processed_results['summary']['unique_services'])
        
        return processed_results
    
    def get_scan_statistics(self) -> Dict[str, Any]:
        """Get current scan statistics"""
        return dict(self.stats)
    
    async def cleanup(self):
        """Cleanup resources"""
        self.executor.shutdown(wait=True)
        self.logger.info("Network scanner cleanup completed")