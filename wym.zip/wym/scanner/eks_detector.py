"""
EKS Cluster Detection Module
Identifies Amazon EKS clusters and Pod Identity configurations
"""

import asyncio
import aiohttp
import json
import ssl
from typing import Dict, List, Optional, Any
from kubernetes import client, config
from kubernetes.client.rest import ApiException
import boto3
from botocore.exceptions import ClientError, NoCredentialsError


class EKSDetector:
    """Detects and analyzes EKS clusters for Pod Identity configurations"""
    
    def __init__(self, framework_config):
        self.config = framework_config
        self.logger = framework_config.logger
        
        # Initialize AWS clients
        self.sts_client = None
        self.eks_client = None
        self._init_aws_clients()
    
    def _init_aws_clients(self):
        """Initialize AWS clients with available credentials"""
        try:
            session = boto3.Session()
            self.sts_client = session.client('sts')
            self.eks_client = session.client('eks')
            
            # Test credentials
            self.sts_client.get_caller_identity()
            self.logger.info("AWS credentials validated for EKS detection")
            
        except (NoCredentialsError, ClientError) as e:
            self.logger.warning(f"AWS credentials not available: {e}")
            self.logger.info("EKS detection will use alternative methods")
    
    async def detect_clusters(self, network_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Detect EKS clusters from network scan results
        """
        clusters = []
        
        # Check for Kubernetes API endpoints
        for host, host_data in network_results.get('hosts', {}).items():
            for port, port_data in host_data.get('ports', {}).items():
                if self._is_kubernetes_api(port_data):
                    cluster_info = await self._analyze_kubernetes_endpoint(host, port)
                    if cluster_info and cluster_info.get('is_eks'):
                        clusters.append(cluster_info)
        
        # If we have AWS credentials, also discover via AWS API
        if self.eks_client:
            aws_clusters = await self._discover_eks_via_aws()
            clusters.extend(aws_clusters)
        
        return {
            'clusters': clusters,
            'detection_methods': ['network_scan', 'aws_api'] if self.eks_client else ['network_scan'],
            'total_found': len(clusters)
        }
    
    def _is_kubernetes_api(self, port_data: Dict[str, Any]) -> bool:
        """Determine if a port likely hosts a Kubernetes API"""
        
        # Common Kubernetes API ports
        if port_data.get('port') in [6443, 443, 8443]:
            return True
        
        # Check service banners for Kubernetes indicators
        service_info = port_data.get('service', {})
        if any(indicator in service_info.get('banner', '').lower() 
               for indicator in ['kubernetes', 'k8s', 'kube-apiserver']):
            return True
        
        return False
    
    async def _analyze_kubernetes_endpoint(self, host: str, port: int) -> Optional[Dict[str, Any]]:
        """
        Analyze a Kubernetes API endpoint to determine if it's EKS
        """
        cluster_info = {
            'host': host,
            'port': port,
            'is_eks': False,
            'pod_identity_enabled': False,
            'version': None,
            'accessible': False
        }
        
        try:
            # Try to connect to the API endpoint
            api_url = f"https://{host}:{port}"
            
            # Create SSL context that allows self-signed certificates for testing
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_NONE
            
            async with aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(ssl=ssl_context),
                timeout=aiohttp.ClientTimeout(total=10)
            ) as session:
                
                # Try to get version info (usually available without auth)
                async with session.get(f"{api_url}/version") as response:
                    if response.status == 200:
                        version_data = await response.json()
                        cluster_info['version'] = version_data
                        cluster_info['accessible'] = True
                        
                        # Check for EKS indicators
                        platform = version_data.get('platform', '')
                        if 'eks' in platform.lower():
                            cluster_info['is_eks'] = True
                
                # Try to get cluster info endpoint
                async with session.get(f"{api_url}/api/v1") as response:
                    if response.status == 200:
                        cluster_info['api_accessible'] = True
                        
                        # Attempt to detect Pod Identity via metadata endpoint test
                        pod_identity_check = await self._check_pod_identity_availability(host)
                        cluster_info['pod_identity_enabled'] = pod_identity_check
        
        except Exception as e:
            self.logger.debug(f"Failed to analyze {host}:{port} - {e}")
        
        return cluster_info if cluster_info['accessible'] else None
    
    async def _check_pod_identity_availability(self, cluster_host: str) -> bool:
        """
        Check if EKS Pod Identity metadata endpoint is accessible
        """
        try:
            # EKS Pod Identity uses a specific metadata endpoint
            metadata_url = "http://169.254.170.23/v1/credentials"
            
            async with aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=5)
            ) as session:
                async with session.get(metadata_url) as response:
                    # If we get any response, Pod Identity might be configured
                    if response.status in [200, 401, 403]:
                        return True
        
        except Exception:
            pass
        
        return False
    
    async def _discover_eks_via_aws(self) -> List[Dict[str, Any]]:
        """
        Discover EKS clusters using AWS API (if credentials available)
        """
        clusters = []
        
        try:
            # List all EKS clusters in available regions
            ec2 = boto3.client('ec2')
            regions = [region['RegionName'] for region in ec2.describe_regions()['Regions']]
            
            for region in regions:
                try:
                    eks_client = boto3.client('eks', region_name=region)
                    
                    # List clusters in this region
                    cluster_list = eks_client.list_clusters()
                    
                    for cluster_name in cluster_list['clusters']:
                        cluster_details = eks_client.describe_cluster(name=cluster_name)
                        cluster_data = cluster_details['cluster']
                        
                        # Check for Pod Identity configuration
                        pod_identity_config = await self._get_pod_identity_config(
                            eks_client, cluster_name
                        )
                        
                        cluster_info = {
                            'name': cluster_name,
                            'region': region,
                            'endpoint': cluster_data['endpoint'],
                            'version': cluster_data['version'],
                            'status': cluster_data['status'],
                            'is_eks': True,
                            'pod_identity_enabled': bool(pod_identity_config),
                            'pod_identity_config': pod_identity_config,
                            'discovery_method': 'aws_api'
                        }
                        
                        clusters.append(cluster_info)
                
                except ClientError as e:
                    if e.response['Error']['Code'] != 'UnauthorizedOperation':
                        self.logger.warning(f"Failed to scan region {region}: {e}")
        
        except Exception as e:
            self.logger.error(f"AWS EKS discovery failed: {e}")
        
        return clusters
    
    async def _get_pod_identity_config(self, eks_client, cluster_name: str) -> Dict[str, Any]:
        """
        Get Pod Identity configuration for an EKS cluster
        """
        try:
            # Check for Pod Identity associations
            response = eks_client.list_pod_identity_associations(clusterName=cluster_name)
            
            associations = []
            for assoc in response.get('associations', []):
                assoc_details = eks_client.describe_pod_identity_association(
                    clusterName=cluster_name,
                    associationId=assoc['associationId']
                )
                associations.append(assoc_details['association'])
            
            return {
                'enabled': len(associations) > 0,
                'associations': associations,
                'association_count': len(associations)
            }
        
        except ClientError as e:
            if 'PodIdentityNotSupported' in str(e):
                return {'enabled': False, 'reason': 'not_supported'}
            elif 'AccessDenied' in str(e):
                return {'enabled': 'unknown', 'reason': 'access_denied'}
        
        return {'enabled': False}