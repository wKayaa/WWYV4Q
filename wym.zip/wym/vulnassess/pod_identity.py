"""
EKS Pod Identity Vulnerability Assessment Module
Analyzes Pod Identity configurations for security vulnerabilities
"""

import asyncio
import json
from typing import Dict, List, Optional, Any
from kubernetes import client, config
from kubernetes.client.rest import ApiException
import boto3
from botocore.exceptions import ClientError


class PodIdentityAnalyzer:
    """Analyzes EKS Pod Identity configurations for vulnerabilities"""
    
    def __init__(self, framework_config):
        self.config = framework_config
        self.logger = framework_config.logger
        
        # Vulnerability patterns to check
        self.vulnerability_checks = [
            self._check_overprivileged_roles,
            self._check_cross_namespace_access,
            self._check_privileged_containers,
            self._check_host_network_access,
            self._check_capability_escalation,
            self._check_metadata_exposure
        ]
    
    async def analyze_clusters(self, clusters: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Analyze multiple EKS clusters for Pod Identity vulnerabilities
        """
        results = {
            'total_clusters': len(clusters),
            'vulnerable_clusters': 0,
            'vulnerabilities': [],
            'summary': {}
        }
        
        for cluster in clusters:
            if not cluster.get('pod_identity_enabled'):
                continue
            
            cluster_vulns = await self._analyze_single_cluster(cluster)
            if cluster_vulns['vulnerabilities']:
                results['vulnerable_clusters'] += 1
                results['vulnerabilities'].extend(cluster_vulns['vulnerabilities'])
        
        # Generate summary statistics
        results['summary'] = self._generate_vulnerability_summary(results['vulnerabilities'])
        
        return results
    
    async def _analyze_single_cluster(self, cluster: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze a single EKS cluster for Pod Identity vulnerabilities
        """
        cluster_results = {
            'cluster': cluster,
            'vulnerabilities': [],
            'analysis_timestamp': asyncio.get_event_loop().time()
        }
        
        try:
            # Attempt to configure Kubernetes client for this cluster
            k8s_client = await self._get_kubernetes_client(cluster)
            
            if k8s_client:
                # Run all vulnerability checks
                for check_func in self.vulnerability_checks:
                    try:
                        vulns = await check_func(k8s_client, cluster)
                        cluster_results['vulnerabilities'].extend(vulns)
                    except Exception as e:
                        self.logger.warning(f"Vulnerability check failed: {e}")
        
        except Exception as e:
            self.logger.error(f"Failed to analyze cluster {cluster.get('name', 'unknown')}: {e}")
        
        return cluster_results
    
    async def _get_kubernetes_client(self, cluster: Dict[str, Any]) -> Optional[client.ApiClient]:
        """
        Attempt to get authenticated Kubernetes client for cluster
        """
        try:
            # Try multiple authentication methods
            
            # Method 1: If we have AWS credentials and cluster info
            if cluster.get('name') and cluster.get('region'):
                try:
                    # Use AWS CLI/SDK authentication
                    config.load_kube_config_from_dict({
                        'apiVersion': 'v1',
                        'clusters': [{
                            'cluster': {
                                'certificate-authority-data': '',
                                'server': cluster.get('endpoint', '')
                            },
                            'name': cluster['name']
                        }],
                        'contexts': [{
                            'context': {
                                'cluster': cluster['name'],
                                'user': cluster['name']
                            },
                            'name': cluster['name']
                        }],
                        'current-context': cluster['name'],
                        'users': [{
                            'name': cluster['name'],
                            'user': {
                                'exec': {
                                    'apiVersion': 'client.authentication.k8s.io/v1beta1',
                                    'command': 'aws',
                                    'args': [
                                        'eks', 'get-token',
                                        '--cluster-name', cluster['name'],
                                        '--region', cluster['region']
                                    ]
                                }
                            }
                        }]
                    })
                    
                    return client.ApiClient()
                    
                except Exception as e:
                    self.logger.debug(f"AWS EKS auth failed: {e}")
            
            # Method 2: Try anonymous access (for read-only operations)
            if cluster.get('endpoint'):
                configuration = client.Configuration()
                configuration.host = cluster['endpoint']
                configuration.verify_ssl = False  # For testing only
                
                return client.ApiClient(configuration)
        
        except Exception as e:
            self.logger.debug(f"Kubernetes client creation failed: {e}")
        
        return None
    
    async def _check_overprivileged_roles(self, k8s_client, cluster: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Check for overprivileged IAM roles associated with Pod Identity
        """
        vulnerabilities = []
        
        try:
            # Get Pod Identity associations from cluster data
            pod_identity_config = cluster.get('pod_identity_config', {})
            associations = pod_identity_config.get('associations', [])
            
            for association in associations:
                role_arn = association.get('roleArn', '')
                
                # Check if role has dangerous permissions
                dangerous_permissions = await self._check_iam_role_permissions(role_arn)
                
                if dangerous_permissions:
                    vulnerabilities.append({
                        'type': 'overprivileged_pod_identity_role',
                        'severity': 'high',
                        'description': f'Pod Identity role {role_arn} has excessive permissions',
                        'details': {
                            'role_arn': role_arn,
                            'association_id': association.get('associationId'),
                            'dangerous_permissions': dangerous_permissions,
                            'namespace': association.get('namespace'),
                            'service_account': association.get('serviceAccount')
                        },
                        'recommendations': [
                            'Apply principle of least privilege to IAM role',
                            'Remove unnecessary permissions',
                            'Use resource-specific permissions'
                        ]
                    })
        
        except Exception as e:
            self.logger.debug(f"Overprivileged role check failed: {e}")
        
        return vulnerabilities
    
    async def _check_privileged_containers(self, k8s_client, cluster: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Check for privileged containers that could exploit Pod Identity
        """
        vulnerabilities = []
        
        try:
            v1 = client.CoreV1Api(k8s_client)
            
            # Get all pods across all namespaces
            pods = v1.list_pod_for_all_namespaces()
            
            for pod in pods.items:
                # Check if pod uses Pod Identity
                if not self._pod_uses_pod_identity(pod):
                    continue
                
                # Check for privileged containers
                for container in pod.spec.containers:
                    security_context = container.security_context or {}
                    
                    if security_context.get('privileged'):
                        vulnerabilities.append({
                            'type': 'privileged_container_with_pod_identity',
                            'severity': 'critical',
                            'description': f'Privileged container {container.name} using Pod Identity',
                            'details': {
                                'pod_name': pod.metadata.name,
                                'namespace': pod.metadata.namespace,
                                'container_name': container.name,
                                'service_account': pod.spec.service_account_name
                            },
                            'exploitation_potential': [
                                'Container escape to host',
                                'Access to host metadata service',
                                'Credential interception'
                            ]
                        })
                
                # Check for dangerous capabilities
                dangerous_caps = self._check_dangerous_capabilities(pod)
                if dangerous_caps:
                    vulnerabilities.append({
                        'type': 'dangerous_capabilities_with_pod_identity',
                        'severity': 'high',
                        'description': f'Pod {pod.metadata.name} has dangerous capabilities',
                        'details': {
                            'pod_name': pod.metadata.name,
                            'namespace': pod.metadata.namespace,
                            'dangerous_capabilities': dangerous_caps,
                            'service_account': pod.spec.service_account_name
                        }
                    })
        
        except ApiException as e:
            self.logger.debug(f"Privileged container check failed: {e}")
        
        return vulnerabilities
    
    async def _check_host_network_access(self, k8s_client, cluster: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Check for pods with host network access that could intercept metadata traffic
        """
        vulnerabilities = []
        
        try:
            v1 = client.CoreV1Api(k8s_client)
            pods = v1.list_pod_for_all_namespaces()
            
            for pod in pods.items:
                if not self._pod_uses_pod_identity(pod):
                    continue
                
                if pod.spec.host_network:
                    vulnerabilities.append({
                        'type': 'host_network_pod_identity_access',
                        'severity': 'critical',
                        'description': f'Pod {pod.metadata.name} has host network access with Pod Identity',
                        'details': {
                            'pod_name': pod.metadata.name,
                            'namespace': pod.metadata.namespace,
                            'service_account': pod.spec.service_account_name,
                            'host_network': True
                        },
                        'exploitation_methods': [
                            'Traffic interception on 169.254.170.23',
                            'Metadata service spoofing',
                            'Credential harvesting'
                        ],
                        'recommendations': [
                            'Remove hostNetwork: true',
                            'Use network policies to restrict access',
                            'Monitor network traffic'
                        ]
                    })
        
        except ApiException as e:
            self.logger.debug(f"Host network check failed: {e}")
        
        return vulnerabilities
    
    def _pod_uses_pod_identity(self, pod) -> bool:
        """Check if a pod is configured to use Pod Identity"""
        
        # Check for Pod Identity annotations
        annotations = pod.metadata.annotations or {}
        
        # EKS Pod Identity uses specific annotations
        pod_identity_indicators = [
            'eks.amazonaws.com/pod-identity-association',
            'eks.amazonaws.com/service-account',
            'eks.amazonaws.com/role-arn'
        ]
        
        return any(indicator in annotations for indicator in pod_identity_indicators)
    
    def _check_dangerous_capabilities(self, pod) -> List[str]:
        """Check for dangerous Linux capabilities"""
        
        dangerous_caps = [
            'CAP_NET_ADMIN',  # Network administration
            'CAP_SYS_ADMIN',  # System administration
            'CAP_NET_RAW',    # Raw socket access
            'CAP_SYS_PTRACE', # Process tracing
            'CAP_DAC_OVERRIDE' # File permission override
        ]
        
        found_dangerous = []
        
        for container in pod.spec.containers:
            security_context = container.security_context or {}
            capabilities = security_context.get('capabilities', {})
            add_caps = capabilities.get('add', [])
            
            for cap in add_caps:
                if cap in dangerous_caps:
                    found_dangerous.append(cap)
        
        return found_dangerous
    
    async def _check_iam_role_permissions(self, role_arn: str) -> List[str]:
        """
        Check IAM role for dangerous permissions
        """
        dangerous_permissions = []
        
        try:
            iam_client = boto3.client('iam')
            
            # Extract role name from ARN
            role_name = role_arn.split('/')[-1]
            
            # Get attached policies
            response = iam_client.list_attached_role_policies(RoleName=role_name)
            
            for policy in response['AttachedPolicies']:
                policy_arn = policy['PolicyArn']
                
                # Get policy document
                policy_response = iam_client.get_policy(PolicyArn=policy_arn)
                version_id = policy_response['Policy']['DefaultVersionId']
                
                policy_version = iam_client.get_policy_version(
                    PolicyArn=policy_arn,
                    VersionId=version_id
                )
                
                # Check for dangerous permissions
                statements = policy_version['PolicyVersion']['Document'].get('Statement', [])
                for statement in statements:
                    if statement.get('Effect') == 'Allow':
                        actions = statement.get('Action', [])
                        if isinstance(actions, str):
                            actions = [actions]
                        
                        # Check for overly broad permissions
                        dangerous_actions = [
                            '*',  # All permissions
                            'iam:*',  # All IAM permissions
                            'sts:AssumeRole',  # Role assumption
                            'ec2:*',  # All EC2 permissions
                            's3:*'   # All S3 permissions
                        ]
                        
                        for action in actions:
                            if action in dangerous_actions:
                                dangerous_permissions.append(action)
        
        except ClientError as e:
            self.logger.debug(f"IAM role permission check failed: {e}")
        
        return dangerous_permissions
    
    async def _check_cross_namespace_access(self, k8s_client, cluster: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check for Pod Identity configurations that allow cross-namespace access"""
        # Implementation for cross-namespace access checks
        return []
    
    async def _check_capability_escalation(self, k8s_client, cluster: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check for capability escalation vulnerabilities"""
        # Implementation for capability escalation checks
        return []
    
    async def _check_metadata_exposure(self, k8s_client, cluster: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check for metadata service exposure vulnerabilities"""
        # Implementation for metadata exposure checks
        return []
    
    def _generate_vulnerability_summary(self, vulnerabilities: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate summary statistics for found vulnerabilities"""
        
        summary = {
            'total_vulnerabilities': len(vulnerabilities),
            'by_severity': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0},
            'by_type': {},
            'most_common_types': []
        }
        
        for vuln in vulnerabilities:
            severity = vuln.get('severity', 'unknown')
            vuln_type = vuln.get('type', 'unknown')
            
            if severity in summary['by_severity']:
                summary['by_severity'][severity] += 1
            
            summary['by_type'][vuln_type] = summary['by_type'].get(vuln_type, 0) + 1
        
        # Sort by most common types
        summary['most_common_types'] = sorted(
            summary['by_type'].items(),
            key=lambda x: x[1],
            reverse=True
        )[:5]
        
        return summary