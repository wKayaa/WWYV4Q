"""
Vulnerability Assessment Module
"""

from .pod_identity import PodIdentityAnalyzer

__all__ = ['PodIdentityAnalyzer']