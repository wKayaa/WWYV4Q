#!/usr/bin/env python3
"""
Quick IP Scanner for EKS Security Framework
Usage: python3 quick_scan.py <ip_range> [ports]
"""

import asyncio
import sys
import argparse
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

from core.config import Config
from core.logging import setup_logging
from scanner.network_scanner import NetworkScanner

async def quick_scan(ip_range: str, ports: list = None, output_file: str = None):
    """
    Quick scan of IP range with minimal setup
    """
    
    # Default ports if none specified
    if not ports:
        ports = [22, 80, 443, 6443, 8080, 8443, 10250, 3000, 9090, 9200]
    
    print(f"🔍 EKS Security Framework - Quick Scan")
    print(f"📅 {asyncio.get_event_loop().time()}")
    print(f"👤 User: wKayaa")
    print("=" * 50)
    print(f"🎯 Target: {ip_range}")
    print(f"🔌 Ports: {', '.join(map(str, ports))}")
    print("=" * 50)
    
    try:
        # Create minimal config
        config_data = {
            'framework': {'name': 'Quick Scan', 'version': '1.0.0'},
            'scanner': {
                'max_concurrent': 50,
                'max_concurrent_targets': 3,
                'timeout': 10,
                'network': {'scan_timeout': 5, 'ping_timeout': 3}
            },
            'logging': {
                'level': 'INFO',
                'format': '%(asctime)s - %(levelname)s - %(message)s',
                'file': 'logs/quick-scan.log'
            }
        }
        
        # Create config object
        from core.config import ConfigSection
        config = type('Config', (), {})()
        for key, value in config_data.items():
            setattr(config, key, ConfigSection(value))
        
        # Setup logging
        logger = setup_logging(config.logging._data)
        
        # Initialize scanner
        scanner = NetworkScanner(config)
        
        print("🚀 Starting scan...")
        start_time = asyncio.get_event_loop().time()
        
        # Run scan
        results = await scanner.scan_range(ip_range, ports)
        
        end_time = asyncio.get_event_loop().time()
        duration = end_time - start_time
        
        # Display results
        print(f"\n📊 Scan Results ({duration:.2f}s):")
        print("=" * 30)
        
        summary = results['summary']
        print(f"📍 Hosts scanned: {summary['total_hosts']}")
        print(f"✅ Responsive hosts: {summary['responsive_hosts']}")
        print(f"🔌 Open ports: {summary['total_open_ports']}")
        print(f"🔍 Unique services: {len(summary['unique_services'])}")
        
        if summary['potential_kubernetes'] > 0:
            print(f"⚠️  Potential Kubernetes: {summary['potential_kubernetes']}")
        
        # Detailed results
        if summary['responsive_hosts'] > 0:
            print(f"\n🔍 Detailed Findings:")
            print("-" * 40)
            
            for host, host_data in results['hosts'].items():
                if host_data['status'] == 'up':
                    print(f"\n📍 {host}")
                    
                    for port, port_data in host_data['ports'].items():
                        service = port_data['service']['name']
                        product = port_data['service'].get('product', '')
                        banner = port_data['service'].get('banner', '')
                        
                        service_info = service
                        if product:
                            service_info += f" ({product})"
                        
                        print(f"   🔌 {port:5d}/tcp  {service_info}")
                        
                        # Security highlights
                        if port in [6443, 8080, 10250, 10255]:
                            print(f"      ⚠️  KUBERNETES SERVICE DETECTED")
                        elif port in [3000, 9090, 9200]:
                            print(f"      📊 Monitoring/Database service")
                        elif port in [80, 443, 8080, 8443]:
                            print(f"      🌐 Web service")
                            if banner and ('server:' in banner.lower() or 'apache' in banner.lower() or 'nginx' in banner.lower()):
                                print(f"      💡 {banner[:50]}...")
                        
                        # Check for interesting services
                        if 'kubernetes' in service.lower() or port == 6443:
                            print(f"      🚨 POTENTIAL EKS CLUSTER!")
                        elif service in ['grafana', 'prometheus', 'elasticsearch']:
                            print(f"      📈 Monitoring stack component")
        
        # Save results if requested
        if output_file:
            import json
            Path(output_file).parent.mkdir(parents=True, exist_ok=True)
            with open(output_file, 'w') as f:
                json.dump(results, f, indent=2, default=str)
            print(f"\n💾 Results saved to: {output_file}")
        
        # Security recommendations
        print(f"\n🔐 Security Notes:")
        if summary['potential_kubernetes'] > 0:
            print("   ⚠️  Kubernetes services detected - check for:")
            print("      • Exposed API servers (port 6443)")
            print("      • Unsecured kubelet (port 10250)")
            print("      • Pod Identity misconfigurations")
        
        print("   📋 Next steps:")
        print("      • Verify authorization for any testing")
        print("      • Check for default credentials")
        print("      • Review service configurations")
        
        # Cleanup
        await scanner.cleanup()
        
        return results
        
    except Exception as e:
        print(f"❌ Scan failed: {e}")
        import traceback
        traceback.print_exc()
        return None

def main():
    """Main CLI for quick scanning"""
    
    parser = argparse.ArgumentParser(
        description="Quick IP Scanner for EKS Security Framework",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 quick_scan.py 192.168.1.0/24
  python3 quick_scan.py 10.0.0.1-10.0.0.50
  python3 quick_scan.py 172.16.1.0/24 --ports 80,443,6443
  python3 quick_scan.py 192.168.1.100 --ports 22,80,443 --output results.json
  
Common port sets:
  --ports web        # 80,443,8080,8443
  --ports k8s        # 6443,8080,10250,10255
  --ports monitoring # 3000,9090,9200,5601
  --ports all        # Comprehensive scan
        """
    )
    
    parser.add_argument('target', help='IP address, range, or CIDR (e.g., 192.168.1.0/24)')
    parser.add_argument('--ports', '-p', help='Comma-separated ports or preset (web,k8s,monitoring,all)')
    parser.add_argument('--output', '-o', help='Save results to JSON file')
    parser.add_argument('--fast', action='store_true', help='Fast scan (fewer ports)')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    
    args = parser.parse_args()
    
    # Parse ports
    ports = None
    if args.ports:
        if args.ports.lower() == 'web':
            ports = [80, 443, 8080, 8443]
        elif args.ports.lower() == 'k8s':
            ports = [6443, 8080, 10250, 10255, 2379, 2380]
        elif args.ports.lower() == 'monitoring':
            ports = [3000, 9090, 9200, 5601, 8086, 8080]
        elif args.ports.lower() == 'all':
            ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 993, 995, 
                    3000, 3306, 5432, 6379, 6443, 8080, 8443, 9090, 9200, 
                    10250, 10255, 2375, 2376, 2379, 2380]
        else:
            try:
                ports = [int(p.strip()) for p in args.ports.split(',')]
            except ValueError:
                print("❌ Invalid port format. Use comma-separated numbers or presets (web,k8s,monitoring,all)")
                return
    
    if args.fast:
        ports = ports[:10] if ports else [22, 80, 443, 6443, 8080]
    
    # Validate IP format
    target = args.target
    if not ('/' in target or '-' in target or target.replace('.', '').replace(':', '').isalnum()):
        print("❌ Invalid IP format. Use: IP, IP/CIDR, or IP-IP range")
        return
    
    # Run scan
    try:
        results = asyncio.run(quick_scan(target, ports, args.output))
        if results:
            print(f"\n✅ Quick scan completed successfully!")
        else:
            print(f"\n❌ Scan failed")
    except KeyboardInterrupt:
        print(f"\n⏹️  Scan interrupted by user")
    except Exception as e:
        print(f"\n❌ Error: {e}")

if __name__ == "__main__":
    main()