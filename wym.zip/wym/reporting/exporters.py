"""
Report Export and Generation Module
"""

import json
import csv
import sqlite3
import asyncio
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional
import logging


class ReportExporter:
    """Export scan results in multiple formats"""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.output_dir = Path(config.reporting.output_dir)
        self.output_dir.mkdir(exist_ok=True)
    
    async def export_results(self, results: Dict[str, Any]) -> Dict[str, str]:
        """
        Export results in all configured formats
        
        Returns:
            Dictionary of format -> file_path mappings
        """
        
        # Create timestamped directory for this scan
        timestamp = datetime.now().strftime("%Y-%m-%d-%H%M%S")
        scan_dir = self.output_dir / f"scan-{timestamp}"
        scan_dir.mkdir(exist_ok=True)
        
        exported_files = {}
        
        # Export in each configured format
        for format_type in self.config.reporting.formats:
            try:
                if format_type == 'json':
                    file_path = await self._export_json(results, scan_dir)
                elif format_type == 'csv':
                    file_path = await self._export_csv(results, scan_dir)
                elif format_type == 'sqlite':
                    file_path = await self._export_sqlite(results, scan_dir)
                else:
                    self.logger.warning(f"Unknown export format: {format_type}")
                    continue
                
                exported_files[format_type] = str(file_path)
                self.logger.info(f"Exported {format_type} report to {file_path}")
            
            except Exception as e:
                self.logger.error(f"Failed to export {format_type} format: {e}")
        
        # Generate summary report
        summary_file = await self._generate_summary_report(results, scan_dir)
        exported_files['summary'] = str(summary_file)
        
        return exported_files
    
    async def _export_json(self, results: Dict[str, Any], output_dir: Path) -> Path:
        """Export results as JSON"""
        
        json_file = output_dir / "detailed-results.json"
        
        # Prepare JSON-serializable data
        export_data = {
            'scan_metadata': {
                'timestamp': results.get('timestamp', datetime.now().isoformat()),
                'framework_version': '1.0.0',
                'export_time': datetime.now().isoformat()
            },
            'target_info': results.get('target', {}),
            'findings': results.get('findings', {}),
            'statistics': self._calculate_statistics(results)
        }
        
        with open(json_file, 'w') as f:
            json.dump(export_data, f, indent=2, default=str)
        
        return json_file
    
    async def _export_csv(self, results: Dict[str, Any], output_dir: Path) -> Path:
        """Export vulnerabilities as CSV"""
        
        csv_file = output_dir / "vulnerabilities.csv"
        
        # Extract vulnerabilities from results
        vulnerabilities = []
        findings = results.get('findings', {})
        
        if 'pod_identity' in findings:
            pod_vulns = findings['pod_identity'].get('vulnerabilities', [])
            vulnerabilities.extend(pod_vulns)
        
        # CSV headers
        headers = [
            'Severity',
            'Type',
            'Description',
            'Host',
            'Port',
            'Service',
            'Recommendation',
            'Details'
        ]
        
        with open(csv_file, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            
            for vuln in vulnerabilities:
                row = [
                    vuln.get('severity', 'unknown'),
                    vuln.get('type', 'unknown'),
                    vuln.get('description', ''),
                    vuln.get('details', {}).get('host', ''),
                    vuln.get('details', {}).get('port', ''),
                    vuln.get('details', {}).get('service', ''),
                    '; '.join(vuln.get('recommendations', [])),
                    json.dumps(vuln.get('details', {}))
                ]
                writer.writerow(row)
        
        return csv_file
    
    async def _export_sqlite(self, results: Dict[str, Any], output_dir: Path) -> Path:
        """Export results to SQLite database"""
        
        db_file = output_dir / "scan-results.db"
        
        conn = sqlite3.connect(str(db_file))
        cursor = conn.cursor()
        
        # Create tables
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                target_range TEXT,
                scan_duration REAL,
                hosts_scanned INTEGER,
                vulnerabilities_found INTEGER
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS vulnerabilities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER,
                severity TEXT,
                type TEXT,
                description TEXT,
                host TEXT,
                port INTEGER,
                details TEXT,
                FOREIGN KEY (scan_id) REFERENCES scans (id)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS credentials (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                scan_id INTEGER,
                source TEXT,
                credential_type TEXT,
                validated BOOLEAN,
                details TEXT,
                FOREIGN KEY (scan_id) REFERENCES scans (id)
            )
        ''')
        
        # Insert scan record
        target_info = results.get('target', {})
        scan_data = (
            results.get('timestamp', datetime.now().isoformat()),
            target_info.get('ip_range', ''),
            0.0,  # Duration - would be calculated
            0,    # Hosts scanned
            0     # Vulnerabilities found
        )
        
        cursor.execute('''
            INSERT INTO scans (timestamp, target_range, scan_duration, hosts_scanned, vulnerabilities_found)
            VALUES (?, ?, ?, ?, ?)
        ''', scan_data)
        
        scan_id = cursor.lastrowid
        
        # Insert vulnerabilities
        findings = results.get('findings', {})
        if 'pod_identity' in findings:
            vulnerabilities = findings['pod_identity'].get('vulnerabilities', [])
            
            for vuln in vulnerabilities:
                vuln_data = (
                    scan_id,
                    vuln.get('severity', 'unknown'),
                    vuln.get('type', 'unknown'),
                    vuln.get('description', ''),
                    vuln.get('details', {}).get('host', ''),
                    vuln.get('details', {}).get('port', 0),
                    json.dumps(vuln.get('details', {}))
                )
                
                cursor.execute('''
                    INSERT INTO vulnerabilities (scan_id, severity, type, description, host, port, details)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', vuln_data)
        
        # Insert credentials
        if 'credentials' in findings:
            credentials = findings['credentials'].get('extraction_details', [])
            
            for cred in credentials:
                cred_data = (
                    scan_id,
                    cred.get('source', 'unknown'),
                    cred.get('credentials', {}).get('type', 'aws'),
                    cred.get('validation', {}).get('valid', False),
                    json.dumps(cred)
                )
                
                cursor.execute('''
                    INSERT INTO credentials (scan_id, source, credential_type, validated, details)
                    VALUES (?, ?, ?, ?, ?)
                ''', cred_data)
        
        conn.commit()
        conn.close()
        
        return db_file
    
    async def _generate_summary_report(self, results: Dict[str, Any], output_dir: Path) -> Path:
        """Generate executive summary report"""
        
        summary_file = output_dir / "summary.json"
        
        findings = results.get('findings', {})
        
        # Calculate summary statistics
        summary = {
            'executive_summary': {
                'scan_date': datetime.now().isoformat(),
                'target': results.get('target', {}).get('ip_range', 'unknown'),
                'total_vulnerabilities': 0,
                'critical_vulnerabilities': 0,
                'high_vulnerabilities': 0,
                'credentials_found': 0,
                'validated_credentials': 0
            },
            'risk_assessment': {
                'overall_risk': 'low',
                'key_findings': [],
                'immediate_actions': []
            },
            'technical_summary': {
                'hosts_discovered': 0,
                'services_identified': 0,
                'kubernetes_clusters': 0,
                'pod_identity_enabled': 0
            }
        }
        
        # Process vulnerability findings
        if 'pod_identity' in findings:
            pod_findings = findings['pod_identity']
            vulnerabilities = pod_findings.get('vulnerabilities', [])
            
            summary['executive_summary']['total_vulnerabilities'] = len(vulnerabilities)
            
            # Count by severity
            for vuln in vulnerabilities:
                severity = vuln.get('severity', '').lower()
                if severity == 'critical':
                    summary['executive_summary']['critical_vulnerabilities'] += 1
                elif severity == 'high':
                    summary['executive_summary']['high_vulnerabilities'] += 1
            
            # Determine overall risk
            if summary['executive_summary']['critical_vulnerabilities'] > 0:
                summary['risk_assessment']['overall_risk'] = 'critical'
            elif summary['executive_summary']['high_vulnerabilities'] > 0:
                summary['risk_assessment']['overall_risk'] = 'high'
            elif summary['executive_summary']['total_vulnerabilities'] > 0:
                summary['risk_assessment']['overall_risk'] = 'medium'
        
        # Process credential findings
        if 'credentials' in findings:
            cred_findings = findings['credentials']
            summary['executive_summary']['credentials_found'] = cred_findings.get('credentials_found', 0)
            summary['executive_summary']['validated_credentials'] = cred_findings.get('validated_credentials', 0)
        
        # Process network findings
        if 'network' in findings:
            network_findings = findings['network']
            summary['technical_summary']['hosts_discovered'] = network_findings.get('summary', {}).get('responsive_hosts', 0)
            summary['technical_summary']['services_identified'] = network_findings.get('summary', {}).get('total_open_ports', 0)
        
        # Process EKS findings
        if 'eks' in findings:
            eks_findings = findings['eks']
            summary['technical_summary']['kubernetes_clusters'] = eks_findings.get('total_found', 0)
            
            clusters = eks_findings.get('clusters', [])
            pod_identity_count = sum(1 for cluster in clusters if cluster.get('pod_identity_enabled'))
            summary['technical_summary']['pod_identity_enabled'] = pod_identity_count
        
        # Generate key findings and recommendations
        summary['risk_assessment']['key_findings'] = self._generate_key_findings(findings)
        summary['risk_assessment']['immediate_actions'] = self._generate_immediate_actions(findings)
        
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=2, default=str)
        
        return summary_file
    
    def _generate_key_findings(self, findings: Dict[str, Any]) -> List[str]:
        """Generate key findings for executive summary"""
        key_findings = []
        
        # EKS/Kubernetes findings
        if 'eks' in findings:
            cluster_count = findings['eks'].get('total_found', 0)
            if cluster_count > 0:
                key_findings.append(f"Discovered {cluster_count} EKS clusters in target environment")
                
                clusters = findings['eks'].get('clusters', [])
                pod_identity_clusters = [c for c in clusters if c.get('pod_identity_enabled')]
                if pod_identity_clusters:
                    key_findings.append(f"{len(pod_identity_clusters)} clusters have Pod Identity enabled")
        
        # Vulnerability findings
        if 'pod_identity' in findings:
            vulns = findings['pod_identity'].get('vulnerabilities', [])
            critical_vulns = [v for v in vulns if v.get('severity') == 'critical']
            if critical_vulns:
                key_findings.append(f"Found {len(critical_vulns)} critical Pod Identity vulnerabilities")
        
        # Credential findings
        if 'credentials' in findings:
            validated_creds = findings['credentials'].get('validated_credentials', 0)
            if validated_creds > 0:
                key_findings.append(f"Successfully extracted and validated {validated_creds} AWS credentials")
        
        return key_findings
    
    def _generate_immediate_actions(self, findings: Dict[str, Any]) -> List[str]:
        """Generate immediate action items"""
        actions = []
        
        # Critical vulnerability actions
        if 'pod_identity' in findings:
            vulns = findings['pod_identity'].get('vulnerabilities', [])
            
            for vuln in vulns:
                if vuln.get('severity') == 'critical':
                    vuln_type = vuln.get('type', '')
                    if 'privileged_container' in vuln_type:
                        actions.append("Remove privileged: true from containers using Pod Identity")
                    elif 'host_network' in vuln_type:
                        actions.append("Disable hostNetwork for pods with Pod Identity access")
        
        # Credential exposure actions
        if 'credentials' in findings:
            validated_creds = findings['credentials'].get('validated_credentials', 0)
            if validated_creds > 0:
                actions.append("Immediately rotate all exposed AWS credentials")
                actions.append("Review and restrict IAM role permissions")
        
        # General security actions
        actions.extend([
            "Implement least-privilege access controls",
            "Enable comprehensive audit logging",
            "Review Pod Identity role mappings"
        ])
        
        return actions
    
    def _calculate_statistics(self, results: Dict[str, Any]) -> Dict[str, Any]:
        """Calculate detailed statistics from scan results"""
        
        stats = {
            'scan_performance': {
                'total_scan_time': 0,
                'hosts_per_second': 0,
                'ports_per_second': 0
            },
            'discovery_stats': {
                'total_hosts': 0,
                'responsive_hosts': 0,
                'total_ports_scanned': 0,
                'open_ports_found': 0
            },
            'security_stats': {
                'vulnerabilities_by_severity': {},
                'vulnerabilities_by_type': {},
                'credential_sources': {},
                'validation_success_rate': 0
            }
        }
        
        # Extract statistics from findings
        findings = results.get('findings', {})
        
        if 'network' in findings:
            network_stats = findings['network'].get('summary', {})
            stats['discovery_stats'].update({
                'total_hosts': network_stats.get('total_hosts', 0),
                'responsive_hosts': network_stats.get('responsive_hosts', 0),
                'open_ports_found': network_stats.get('total_open_ports', 0)
            })
        
        if 'pod_identity' in findings:
            vulnerabilities = findings['pod_identity'].get('vulnerabilities', [])
            
            # Count by severity
            severity_counts = {}
            type_counts = {}
            
            for vuln in vulnerabilities:
                severity = vuln.get('severity', 'unknown')
                vuln_type = vuln.get('type', 'unknown')
                
                severity_counts[severity] = severity_counts.get(severity, 0) + 1
                type_counts[vuln_type] = type_counts.get(vuln_type, 0) + 1
            
            stats['security_stats']['vulnerabilities_by_severity'] = severity_counts
            stats['security_stats']['vulnerabilities_by_type'] = type_counts
        
        return stats