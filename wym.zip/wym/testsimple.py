#!/usr/bin/env python3
"""
Simple test to verify the framework setup
"""

import sys
from pathlib import Path

def test_imports():
    """Test that all modules can be imported"""
    
    print("?? Testing EKS Security Framework imports...")
    
    try:
        print("?? Testing core modules...")
        from core.config import Config
        from core.logging import setup_logging
        from core.plugin_manager import PluginManager
        print("? Core modules imported successfully")
        
        print("?? Testing scanner modules...")
        from scanner.network_scanner import NetworkScanner
        from scanner.eks_detector import EKSDetector
        from scanner.service_detector import ServiceDetector
        print("? Scanner modules imported successfully")
        
        print("?? Testing security modules...")
        from vulnassess.pod_identity import PodIdentityAnalyzer
        from credentials.extractor import CredentialExtractor
        from reporting.exporters import ReportExporter
        print("? Security modules imported successfully")
        
        print("?? Testing configuration loading...")
        config = Config("config/settings.yaml")
        print("? Configuration loaded successfully")
        
        print("\n?? All imports successful!")
        return True
        
    except Exception as e:
        print(f"? Import test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_imports()
    
    if success:
        print("\n?? Framework is ready!")
        print("\nQuick start commands:")
        print("1. Review config: nano config/settings.yaml")
        print("2. Add targets: nano config/targets.yaml")
        print("3. Run scan: python3 -m core.engine")
    else:
        print("\n? Framework setup needs attention")
    
    sys.exit(0 if success else 1)