#!/usr/bin/env python3
"""
Demo scan to test framework functionality
"""

import asyncio
import sys
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

from core.config import Config
from core.logging import setup_logging
from scanner.network_scanner import NetworkScanner

async def demo_scan():
    """Run a demo scan on localhost"""
    
    print("?? EKS Security Framework - Demo Scan")
    print("=" * 50)
    
    try:
        # Load configuration
        config = Config("config/settings.yaml")
        logger = setup_logging(config.logging._data)
        
        # Initialize scanner
        scanner = NetworkScanner(config)
        
        # Scan localhost (safe demo)
        print("?? Scanning localhost for demo...")
        results = await scanner.scan_range("127.0.0.1/32", [22, 80, 443, 8080])
        
        # Display results
        print(f"\n?? Scan Results:")
        print(f"   Hosts scanned: {results['summary']['total_hosts']}")
        print(f"   Responsive hosts: {results['summary']['responsive_hosts']}")
        print(f"   Open ports found: {results['summary']['total_open_ports']}")
        
        if results['summary']['responsive_hosts'] > 0:
            print(f"\n?? Detected services:")
            for host, host_data in results['hosts'].items():
                if host_data['status'] == 'up':
                    print(f"   Host: {host}")
                    for port, port_data in host_data['ports'].items():
                        service = port_data['service']['name']
                        print(f"     Port {port}: {service}")
        
        print(f"\n? Demo scan completed successfully!")
        
    except Exception as e:
        print(f"? Demo scan failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(demo_scan())