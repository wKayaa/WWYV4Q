"""
EKS Pod Identity Security Research Framework
Core module initialization
"""

__version__ = "1.0.0"
__author__ = "wKayaa"
__description__ = "Advanced EKS Pod Identity Security Research Framework"

from .engine import SecurityFramework
from .config import Config
from .logging import setup_logging

__all__ = ['SecurityFramework', 'Config', 'setup_logging']