"""
Configuration Management for EKS Security Framework
"""

import yaml
import os
from pathlib import Path
from typing import Dict, Any, Optional
import logging


class Config:
    """Configuration manager for the security framework"""
    
    def __init__(self, config_path: str = "config/settings.yaml"):
        self.config_path = Path(config_path)
        self._config_data = {}
        self.logger = logging.getLogger(__name__)
        
        self._load_config()
        self._validate_config()
        self._setup_paths()
    
    def _load_config(self):
        """Load configuration from YAML file"""
        try:
            if not self.config_path.exists():
                raise FileNotFoundError(f"Configuration file not found: {self.config_path}")
            
            with open(self.config_path, 'r') as f:
                self._config_data = yaml.safe_load(f)
            
            self.logger.info(f"Configuration loaded from {self.config_path}")
            
        except Exception as e:
            self.logger.error(f"Failed to load configuration: {e}")
            raise
    
    def _validate_config(self):
        """Validate required configuration sections"""
        required_sections = [
            'framework',
            'scanner',
            'security',
            'logging'
        ]
        
        for section in required_sections:
            if section not in self._config_data:
                raise ValueError(f"Missing required configuration section: {section}")
        
        # Validate security settings
        if not self._config_data['security']['require_authorization']:
            self.logger.warning("Authorization requirement is disabled - this is dangerous!")
    
    def _setup_paths(self):
        """Setup and create necessary directories"""
        paths_to_create = [
            self.logging['file'],
            self.logging.get('audit', {}).get('file', ''),
            self.reporting['output_dir'],
            self.security['authorization_dir']
        ]
        
        for path_str in paths_to_create:
            if path_str:
                path = Path(path_str)
                path.parent.mkdir(parents=True, exist_ok=True)
    
    def __getattr__(self, name: str) -> Any:
        """Allow dot notation access to configuration sections"""
        if name in self._config_data:
            return ConfigSection(self._config_data[name])
        raise AttributeError(f"Configuration section '{name}' not found")
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value with optional default"""
        return self._config_data.get(key, default)
    
    def update(self, updates: Dict[str, Any]):
        """Update configuration values"""
        self._config_data.update(updates)
    
    def save(self, path: Optional[str] = None):
        """Save current configuration to file"""
        save_path = Path(path) if path else self.config_path
        
        with open(save_path, 'w') as f:
            yaml.dump(self._config_data, f, default_flow_style=False, indent=2)
        
        self.logger.info(f"Configuration saved to {save_path}")


class ConfigSection:
    """Wrapper for configuration sections to allow dot notation"""
    
    def __init__(self, data: Dict[str, Any]):
        self._data = data
    
    def __getattr__(self, name: str) -> Any:
        if name in self._data:
            value = self._data[name]
            if isinstance(value, dict):
                return ConfigSection(value)
            return value
        raise AttributeError(f"Configuration key '{name}' not found")
    
    def __getitem__(self, key: str) -> Any:
        return self._data[key]
    
    def get(self, key: str, default: Any = None) -> Any:
        return self._data.get(key, default)
    
    def items(self):
        return self._data.items()
    
    def keys(self):
        return self._data.keys()
    
    def values(self):
        return self._data.values()