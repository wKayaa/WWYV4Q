"""
Logging configuration for EKS Security Framework
"""

import logging
import logging.handlers
import sys
from pathlib import Path
from typing import Dict, Any
import re


def setup_logging(config: Dict[str, Any]) -> logging.Logger:
    """
    Setup comprehensive logging for the framework
    
    Args:
        config: Logging configuration dictionary
        
    Returns:
        Configured logger instance
    """
    
    # Create formatter
    formatter = logging.Formatter(
        config.get('format', '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    )
    
    # Get or create main logger
    logger = logging.getLogger('eks_security_framework')
    logger.setLevel(getattr(logging, config.get('level', 'INFO')))
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler
    log_file = config.get('file', 'logs/framework.log')
    if log_file:
        # Ensure log directory exists
        Path(log_file).parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=_parse_size(config.get('max_size', '10MB')),
            backupCount=config.get('backup_count', 5)
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    # Audit logger (separate from main logging)
    audit_config = config.get('audit', {})
    if audit_config.get('enabled', False):
        setup_audit_logging(audit_config, formatter)
    
    logger.info("Logging system initialized")
    return logger


def setup_audit_logging(audit_config: Dict[str, Any], formatter: logging.Formatter):
    """Setup separate audit logging"""
    
    audit_logger = logging.getLogger('eks_security_framework.audit')
    audit_logger.setLevel(logging.INFO)
    audit_logger.handlers.clear()
    
    # Audit file handler
    audit_file = audit_config.get('file', 'logs/audit.log')
    if audit_file:
        Path(audit_file).parent.mkdir(parents=True, exist_ok=True)
        
        audit_handler = logging.handlers.RotatingFileHandler(
            audit_file,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=10
        )
        
        # Audit-specific formatter
        audit_formatter = logging.Formatter(
            '%(asctime)s - AUDIT - %(levelname)s - %(message)s'
        )
        audit_handler.setFormatter(audit_formatter)
        audit_logger.addHandler(audit_handler)


def _parse_size(size_str: str) -> int:
    """Parse size string like '10MB' to bytes"""
    if not size_str:
        return 10 * 1024 * 1024  # Default 10MB
    
    size_str = str(size_str).upper().strip()
    
    # Use regex to extract number and unit
    match = re.match(r'^(\d+(?:\.\d+)?)\s*([KMGT]?B?)$', size_str)
    
    if not match:
        # If no match, try to parse as plain number (assume bytes)
        try:
            return int(float(size_str))
        except ValueError:
            # Default fallback
            return 10 * 1024 * 1024
    
    number_str, unit = match.groups()
    number = float(number_str)
    
    # Define multipliers
    multipliers = {
        'B': 1,
        '': 1,  # No unit means bytes
        'KB': 1024,
        'K': 1024,
        'MB': 1024**2,
        'M': 1024**2,
        'GB': 1024**3,
        'G': 1024**3,
        'TB': 1024**4,
        'T': 1024**4
    }
    
    multiplier = multipliers.get(unit, 1)
    return int(number * multiplier)


def get_audit_logger() -> logging.Logger:
    """Get the audit logger instance"""
    return logging.getLogger('eks_security_framework.audit')


def audit_log(message: str, **kwargs):
    """Log an audit message with additional context"""
    audit_logger = get_audit_logger()
    
    # Add context to message
    context_parts = []
    for key, value in kwargs.items():
        context_parts.append(f"{key}={value}")
    
    if context_parts:
        full_message = f"{message} | {' | '.join(context_parts)}"
    else:
        full_message = message
    
    audit_logger.info(full_message)