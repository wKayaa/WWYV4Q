"""
EKS Security Framework - Core Engine
Main orchestration engine for the security research framework
"""

import asyncio
import logging
import signal
import sys
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from pathlib import Path
import yaml

from .config import Config
from .plugin_manager import PluginManager
from .logging import setup_logging
from scanner.network_scanner import NetworkScanner
from scanner.eks_detector import EKSDetector
from vulnassess.pod_identity import PodIdentityAnalyzer
from credentials.extractor import CredentialExtractor
from reporting.exporters import ReportExporter


@dataclass
class ScanTarget:
    """Represents a scan target with metadata"""
    ip_range: str
    ports: List[int]
    authorization: str  # Required authorization reference
    scope: str
    metadata: Dict[str, Any]


class SecurityFramework:
    """Main security research framework engine"""
    
    def __init__(self, config_path: str = "config/settings.yaml"):
        self.config = Config(config_path)
        self.plugin_manager = PluginManager()
        self.logger = setup_logging(self.config.logging)
        
        # Core components
        self.network_scanner = NetworkScanner(self.config)
        self.eks_detector = EKSDetector(self.config)
        self.pod_analyzer = PodIdentityAnalyzer(self.config)
        self.credential_extractor = CredentialExtractor(self.config)
        self.reporter = ReportExporter(self.config)
        
        # State management
        self.running = False
        self.scan_results = {}
        self.shutdown_event = asyncio.Event()
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully"""
        self.logger.info(f"Received signal {signum}, initiating shutdown...")
        self.shutdown_event.set()
    
    async def validate_authorization(self, target: ScanTarget) -> bool:
        """
        Validate authorization for target scanning
        CRITICAL: This must verify written authorization exists
        """
        self.logger.info(f"Validating authorization for {target.ip_range}")
        
        # Check for authorization documentation
        auth_file = Path(f"authorizations/{target.authorization}.yaml")
        if not auth_file.exists():
            self.logger.error(f"No authorization file found: {auth_file}")
            return False
        
        try:
            with open(auth_file) as f:
                auth_data = yaml.safe_load(f)
            
            required_fields = ['target_owner', 'authorization_date', 'scope', 'contact']
            if not all(field in auth_data for field in required_fields):
                self.logger.error("Authorization file missing required fields")
                return False
            
            # Additional validation logic here
            self.logger.info(f"Authorization validated for {target.ip_range}")
            return True
            
        except Exception as e:
            self.logger.error(f"Authorization validation failed: {e}")
            return False
    
    async def scan_target(self, target: ScanTarget) -> Dict[str, Any]:
        """Execute comprehensive scan on a single target"""
        
        if not await self.validate_authorization(target):
            raise ValueError(f"Authorization validation failed for {target.ip_range}")
        
        results = {
            'target': target,
            'timestamp': asyncio.get_event_loop().time(),
            'findings': {}
        }
        
        try:
            # Phase 1: Network Discovery
            self.logger.info(f"Starting network scan for {target.ip_range}")
            network_results = await self.network_scanner.scan_range(
                target.ip_range, 
                target.ports,
                concurrency=self.config.scanner.max_concurrent
            )
            results['findings']['network'] = network_results
            
            # Phase 2: EKS Detection
            self.logger.info("Detecting EKS clusters...")
            eks_results = await self.eks_detector.detect_clusters(network_results)
            results['findings']['eks'] = eks_results
            
            # Phase 3: Pod Identity Analysis
            if eks_results.get('clusters'):
                self.logger.info("Analyzing Pod Identity configurations...")
                pod_results = await self.pod_analyzer.analyze_clusters(
                    eks_results['clusters']
                )
                results['findings']['pod_identity'] = pod_results
                
                # Phase 4: Credential Extraction (if vulnerabilities found)
                if pod_results.get('vulnerabilities'):
                    self.logger.info("Extracting credentials from vulnerable configurations...")
                    cred_results = await self.credential_extractor.extract_from_findings(
                        pod_results['vulnerabilities']
                    )
                    results['findings']['credentials'] = cred_results
            
            # Generate reports
            await self.reporter.export_results(results)
            
        except Exception as e:
            self.logger.error(f"Scan failed for {target.ip_range}: {e}")
            results['error'] = str(e)
        
        return results
    
    async def run_batch_scan(self, targets: List[ScanTarget]) -> Dict[str, Any]:
        """Execute scans on multiple targets with controlled concurrency"""
        
        self.logger.info(f"Starting batch scan on {len(targets)} targets")
        self.running = True
        
        semaphore = asyncio.Semaphore(self.config.scanner.max_concurrent_targets)
        
        async def scan_with_semaphore(target):
            async with semaphore:
                if self.shutdown_event.is_set():
                    return None
                return await self.scan_target(target)
        
        # Execute scans with controlled concurrency
        tasks = [scan_with_semaphore(target) for target in targets]
        batch_results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Compile results
        results = {
            'batch_summary': {
                'total_targets': len(targets),
                'successful_scans': len([r for r in batch_results if isinstance(r, dict) and 'error' not in r]),
                'failed_scans': len([r for r in batch_results if isinstance(r, Exception) or (isinstance(r, dict) and 'error' in r)]),
                'timestamp': asyncio.get_event_loop().time()
            },
            'individual_results': batch_results
        }
        
        self.running = False
        return results
    
    async def start_interactive_mode(self):
        """Start interactive scanning mode with web interface"""
        # Implementation for optional web dashboard
        pass
    
    def load_targets_from_config(self, config_file: str = "config/targets.yaml") -> List[ScanTarget]:
        """Load scan targets from configuration file"""
        
        with open(config_file) as f:
            target_config = yaml.safe_load(f)
        
        targets = []
        for target_data in target_config.get('targets', []):
            target = ScanTarget(
                ip_range=target_data['ip_range'],
                ports=target_data.get('ports', [22, 80, 443, 6443, 8080, 10250]),
                authorization=target_data['authorization'],
                scope=target_data.get('scope', 'full'),
                metadata=target_data.get('metadata', {})
            )
            targets.append(target)
        
        return targets


async def main():
    """Main entry point for the framework"""
    
    framework = SecurityFramework()
    
    try:
        # Load targets from configuration
        targets = framework.load_targets_from_config()
        
        if not targets:
            framework.logger.error("No valid targets found in configuration")
            return
        
        # Execute batch scan
        results = await framework.run_batch_scan(targets)
        
        # Print summary
        summary = results['batch_summary']
        print(f"\nScan Complete:")
        print(f"  Total Targets: {summary['total_targets']}")
        print(f"  Successful: {summary['successful_scans']}")
        print(f"  Failed: {summary['failed_scans']}")
        
    except KeyboardInterrupt:
        framework.logger.info("Scan interrupted by user")
    except Exception as e:
        framework.logger.error(f"Framework error: {e}")


if __name__ == "__main__":
    asyncio.run(main())