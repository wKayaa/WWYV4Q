"""
Plugin Manager for EKS Security Framework
Handles dynamic loading and management of security plugins
"""

import importlib
import inspect
import logging
from pathlib import Path
from typing import Dict, List, Any, Type, Optional
import sys


class PluginManager:
    """Manages loading and execution of security plugins"""
    
    def __init__(self, plugin_dir: str = "plugins"):
        self.plugin_dir = Path(plugin_dir)
        self.logger = logging.getLogger(__name__)
        self.loaded_plugins = {}
        self.plugin_categories = {
            'scanners': [],
            'exploits': [],
            'analyzers': [],
            'extractors': [],
            'reporters': []
        }
        
        # Ensure plugin directory exists
        self.plugin_dir.mkdir(exist_ok=True)
        
        # Create __init__.py if it doesn't exist
        init_file = self.plugin_dir / "__init__.py"
        if not init_file.exists():
            init_file.write_text("# EKS Security Framework Plugins\n")
    
    def load_plugins(self) -> Dict[str, Any]:
        """Load all available plugins from the plugins directory"""
        
        self.logger.info(f"Loading plugins from {self.plugin_dir}")
        
        # Add plugin directory to Python path
        if str(self.plugin_dir.parent) not in sys.path:
            sys.path.insert(0, str(self.plugin_dir.parent))
        
        # Find all Python files in plugin directory
        plugin_files = list(self.plugin_dir.glob("*.py"))
        plugin_files = [f for f in plugin_files if f.name != "__init__.py"]
        
        loaded_count = 0
        for plugin_file in plugin_files:
            try:
                plugin_name = plugin_file.stem
                module_name = f"plugins.{plugin_name}"
                
                # Import the plugin module
                module = importlib.import_module(module_name)
                
                # Find plugin classes in the module
                plugin_classes = self._find_plugin_classes(module)
                
                for plugin_class in plugin_classes:
                    self._register_plugin(plugin_name, plugin_class)
                    loaded_count += 1
                
            except Exception as e:
                self.logger.warning(f"Failed to load plugin {plugin_file}: {e}")
        
        self.logger.info(f"Loaded {loaded_count} plugins")
        return self.loaded_plugins
    
    def _find_plugin_classes(self, module) -> List[Type]:
        """Find plugin classes in a module"""
        plugin_classes = []
        
        for name, obj in inspect.getmembers(module, inspect.isclass):
            # Check if class has plugin interface
            if hasattr(obj, 'plugin_type') and hasattr(obj, 'execute'):
                plugin_classes.append(obj)
        
        return plugin_classes
    
    def _register_plugin(self, name: str, plugin_class: Type):
        """Register a plugin class"""
        
        plugin_type = getattr(plugin_class, 'plugin_type', 'unknown')
        
        self.loaded_plugins[name] = {
            'class': plugin_class,
            'type': plugin_type,
            'name': name,
            'description': getattr(plugin_class, 'description', ''),
            'version': getattr(plugin_class, 'version', '1.0.0')
        }
        
        # Add to appropriate category
        if plugin_type in self.plugin_categories:
            self.plugin_categories[plugin_type].append(name)
        
        self.logger.debug(f"Registered plugin: {name} (type: {plugin_type})")
    
    def get_plugins_by_type(self, plugin_type: str) -> List[str]:
        """Get list of plugin names by type"""
        return self.plugin_categories.get(plugin_type, [])
    
    def execute_plugin(self, plugin_name: str, *args, **kwargs) -> Any:
        """Execute a specific plugin"""
        
        if plugin_name not in self.loaded_plugins:
            raise ValueError(f"Plugin '{plugin_name}' not found")
        
        plugin_info = self.loaded_plugins[plugin_name]
        plugin_class = plugin_info['class']
        
        try:
            # Instantiate and execute plugin
            plugin_instance = plugin_class()
            return plugin_instance.execute(*args, **kwargs)
        
        except Exception as e:
            self.logger.error(f"Plugin execution failed for {plugin_name}: {e}")
            raise
    
    def list_plugins(self) -> Dict[str, Any]:
        """List all loaded plugins with their information"""
        return {
            name: {
                'type': info['type'],
                'description': info['description'],
                'version': info['version']
            }
            for name, info in self.loaded_plugins.items()
        }


class BasePlugin:
    """Base class for security framework plugins"""
    
    plugin_type = "base"
    description = "Base plugin class"
    version = "1.0.0"
    
    def __init__(self):
        self.logger = logging.getLogger(f"plugin.{self.__class__.__name__}")
    
    def execute(self, *args, **kwargs) -> Any:
        """Execute plugin functionality - must be implemented by subclasses"""
        raise NotImplementedError("Plugin must implement execute method")
    
    def validate_input(self, *args, **kwargs) -> bool:
        """Validate plugin input - can be overridden by subclasses"""
        return True