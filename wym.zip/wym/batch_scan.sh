#!/bin/bash
echo "🔍 EKS Security Framework - Batch IP Scanner"
echo "============================================="
echo "📅 Date: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
echo "👤 User: wKayaa"
echo ""

# Define your target IPs/ranges here
IPS=(
    "127.0.0.1"
    "192.168.1.0/28"
    "10.0.0.1"
)

echo "🎯 Targets to scan:"
for ip in "${IPS[@]}"; do
    echo "   - $ip"
done
echo ""

# Scan each target
for i in "${!IPS[@]}"; do
    ip="${IPS[$i]}"
    echo "📡 [$((i+1))/${#IPS[@]}] Scanning $ip..."
    echo "----------------------------------------"
    
    if python3 quick_scan.py "$ip" --ports k8s --fast; then
        echo "✅ Scan completed for $ip"
    else
        echo "❌ Scan failed for $ip"
    fi
    
    echo ""
    sleep 1  # Brief pause between scans
done

echo "🎉 Batch scan completed!"
